﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyPOS.Entities
{
    public class DGVRepHourlyTopSellingSalesReportEntities
    {
        public String ColumnHour { get; set; }
        public String ColumnNo { get; set; }
        public String ColumnCategory { get; set; }
        public String ColumnItemDescription { get; set; }
        public String ColumnQuantity { get; set; }
        public String ColumnUnit { get; set; }
        public String ColumnPrice { get; set; }
        public String ColumnAmount { get; set; }
    }
}
