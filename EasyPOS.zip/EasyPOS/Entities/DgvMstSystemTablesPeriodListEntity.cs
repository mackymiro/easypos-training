﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyPOS.Entities
{
    public class DgvMstSystemTablesPeriodListEntity
    {
        public String ColumnPeriodListButtonEdit { get; set; }
        public String ColumnPeriodListButtonDelete { get; set; }
        public Int32 ColumnPeriodListId { get; set; }
        public String ColumnPeriodListPeriod { get; set; }
    }
}
