﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyPOS.Entities
{
    public class DgvSalesSummaryRewardReportEntity
    {
        public String ColumnCustomer { get; set; }
        public String ColumnRewardNo { get; set; }
        public String ColumnAvailableReward { get; set; }
        public String ColumnTotalClaimReward { get; set; }
    }
}
