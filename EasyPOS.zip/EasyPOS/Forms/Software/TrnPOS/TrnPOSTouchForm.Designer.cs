﻿namespace EasyPOS.Forms.Software.TrnPOS
{
    partial class TrnPOSTouchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrnPOSTouchForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle57 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle58 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle64 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle65 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle59 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle60 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle61 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle62 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle63 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle66 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle67 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle73 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle74 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle68 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle69 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle70 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle71 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle72 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle75 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle76 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle83 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle84 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle77 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle78 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle79 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle80 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle81 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle82 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonClose = new System.Windows.Forms.Button();
            this.imageListPOSTouch = new System.Windows.Forms.ImageList(this.components);
            this.panel3 = new System.Windows.Forms.Panel();
            this.tabControlSales = new System.Windows.Forms.TabControl();
            this.tabPageOpen = new System.Windows.Forms.TabPage();
            this.dataGridViewOpenSalesList = new System.Windows.Forms.DataGridView();
            this.TabPageOpenColumnEdit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.TabPageOpenColumnDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.TabPageOpenColumnId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnTerminal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnSalesDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnSalesNumber = new System.Windows.Forms.DataGridViewLinkColumn();
            this.TabPageOpenColumnManualSalesNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnRececiptInvoiceNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnCustomerCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnSalesAgent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnTable = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnIsLocked = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.TabPageOpenColumnIsTendered = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.TabPageOpenColumnIsCancelled = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.TabPageOpenColumnRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnDelivery = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TabPageOpenColumnSpace = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOut = new System.Windows.Forms.TabPage();
            this.dataGridViewBilledOutSalesList = new System.Windows.Forms.DataGridView();
            this.tabPageBilledOutColumnEdit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tabPageBilledOutColumnDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tabPageBilledOutColumnId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnTerminal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnSalesDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnSalesNumber = new System.Windows.Forms.DataGridViewLinkColumn();
            this.tabPageBilledOutColumnManualSalesNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnInvoiceNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnCustomerCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnSalesAgent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnTable = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnIsLocked = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPageBilledOutColumnIsTendered = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPageBilledOutColumnIsCancelled = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPageBilledOutColumnRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnDelivery = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageBilledOutColumnSpace = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollected = new System.Windows.Forms.TabPage();
            this.dataGridViewCollectedSalesList = new System.Windows.Forms.DataGridView();
            this.tabPageCollectedColumnEdit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tabPageCollectedColumnDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tabPageCollectedColumnId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnTerminal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnSalesDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnSalesNumber = new System.Windows.Forms.DataGridViewLinkColumn();
            this.tabPageCollectedColumnManualSalesNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnCollectionNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnCustomerCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnCustomer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnSalesAgent = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnTable = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnIsLocked = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPageCollectedColumnIsTendered = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPageCollectedColumnIsCancelled = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPageCollectedColumnRemarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnDelivery = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPageCollectedColumnSpace = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.textBoxTotalAmount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonTenderAll = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBoxLastChange = new System.Windows.Forms.TextBox();
            this.labelLastChange = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.buttonHideItems = new System.Windows.Forms.Button();
            this.panelWalkIn = new System.Windows.Forms.Panel();
            this.textBoxFilter = new System.Windows.Forms.TextBox();
            this.comboBoxTerminal = new System.Windows.Forms.ComboBox();
            this.dateTimePickerSalesDate = new System.Windows.Forms.DateTimePicker();
            this.panel6 = new System.Windows.Forms.Panel();
            this.buttonDelivery = new System.Windows.Forms.Button();
            this.buttonWalkIn = new System.Windows.Forms.Button();
            this.buttonTableGroup4 = new System.Windows.Forms.Button();
            this.buttonTableGroup5 = new System.Windows.Forms.Button();
            this.buttonTableGroup6 = new System.Windows.Forms.Button();
            this.buttonTableGroup1 = new System.Windows.Forms.Button();
            this.buttonTableGroup2 = new System.Windows.Forms.Button();
            this.buttonTableGroup3 = new System.Windows.Forms.Button();
            this.buttonTable4 = new System.Windows.Forms.Button();
            this.buttonTable5 = new System.Windows.Forms.Button();
            this.buttonTable6 = new System.Windows.Forms.Button();
            this.buttonTable10 = new System.Windows.Forms.Button();
            this.buttonTable11 = new System.Windows.Forms.Button();
            this.buttonTable12 = new System.Windows.Forms.Button();
            this.buttonTable16 = new System.Windows.Forms.Button();
            this.buttonTable17 = new System.Windows.Forms.Button();
            this.buttonTable18 = new System.Windows.Forms.Button();
            this.buttonTable22 = new System.Windows.Forms.Button();
            this.buttonTable23 = new System.Windows.Forms.Button();
            this.buttonTable24 = new System.Windows.Forms.Button();
            this.buttonTable1 = new System.Windows.Forms.Button();
            this.buttonTable2 = new System.Windows.Forms.Button();
            this.buttonTable3 = new System.Windows.Forms.Button();
            this.buttonTable7 = new System.Windows.Forms.Button();
            this.buttonTable8 = new System.Windows.Forms.Button();
            this.buttonTable9 = new System.Windows.Forms.Button();
            this.buttonTable13 = new System.Windows.Forms.Button();
            this.buttonTable14 = new System.Windows.Forms.Button();
            this.buttonTable15 = new System.Windows.Forms.Button();
            this.buttonTable19 = new System.Windows.Forms.Button();
            this.buttonTable20 = new System.Windows.Forms.Button();
            this.buttonTable21 = new System.Windows.Forms.Button();
            this.buttonTable28 = new System.Windows.Forms.Button();
            this.buttonTable29 = new System.Windows.Forms.Button();
            this.buttonTable30 = new System.Windows.Forms.Button();
            this.buttonTable25 = new System.Windows.Forms.Button();
            this.buttonTable26 = new System.Windows.Forms.Button();
            this.buttonTable27 = new System.Windows.Forms.Button();
            this.buttonTableNext = new System.Windows.Forms.Button();
            this.buttonTableGroupPageNext = new System.Windows.Forms.Button();
            this.buttonTablePrevious = new System.Windows.Forms.Button();
            this.buttonTableGroupPagePrevious = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel3.SuspendLayout();
            this.tabControlSales.SuspendLayout();
            this.tabPageOpen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOpenSalesList)).BeginInit();
            this.tabPageBilledOut.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBilledOutSalesList)).BeginInit();
            this.tabPageCollected.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCollectedSalesList)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panelWalkIn.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.buttonClose);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1096, 50);
            this.panel1.TabIndex = 4;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::EasyPOS.Properties.Resources.POS_Touch;
            this.pictureBox1.Location = new System.Drawing.Point(10, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(50, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 28);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sales";
            // 
            // buttonClose
            // 
            this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(79)))), ((int)(((byte)(28)))));
            this.buttonClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(79)))), ((int)(((byte)(28)))));
            this.buttonClose.FlatAppearance.BorderSize = 0;
            this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClose.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClose.ForeColor = System.Drawing.Color.White;
            this.buttonClose.Location = new System.Drawing.Point(1016, 10);
            this.buttonClose.Margin = new System.Windows.Forms.Padding(2);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(70, 32);
            this.buttonClose.TabIndex = 1;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = false;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // imageListPOSTouch
            // 
            this.imageListPOSTouch.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListPOSTouch.ImageStream")));
            this.imageListPOSTouch.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListPOSTouch.Images.SetKeyName(0, "delivery.png");
            this.imageListPOSTouch.Images.SetKeyName(1, "walkin.png");
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tabControlSales);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.panelWalkIn);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.ForeColor = System.Drawing.Color.White;
            this.panel3.Location = new System.Drawing.Point(0, 50);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1096, 511);
            this.panel3.TabIndex = 15;
            // 
            // tabControlSales
            // 
            this.tabControlSales.Controls.Add(this.tabPageOpen);
            this.tabControlSales.Controls.Add(this.tabPageBilledOut);
            this.tabControlSales.Controls.Add(this.tabPageCollected);
            this.tabControlSales.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlSales.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tabControlSales.Location = new System.Drawing.Point(668, 0);
            this.tabControlSales.Margin = new System.Windows.Forms.Padding(2);
            this.tabControlSales.Name = "tabControlSales";
            this.tabControlSales.SelectedIndex = 0;
            this.tabControlSales.Size = new System.Drawing.Size(428, 411);
            this.tabControlSales.TabIndex = 41;
            this.tabControlSales.SelectedIndexChanged += new System.EventHandler(this.tabControlSales_SelectedIndexChanged);
            // 
            // tabPageOpen
            // 
            this.tabPageOpen.Controls.Add(this.dataGridViewOpenSalesList);
            this.tabPageOpen.Location = new System.Drawing.Point(4, 30);
            this.tabPageOpen.Margin = new System.Windows.Forms.Padding(0);
            this.tabPageOpen.Name = "tabPageOpen";
            this.tabPageOpen.Size = new System.Drawing.Size(420, 377);
            this.tabPageOpen.TabIndex = 0;
            this.tabPageOpen.Text = "Open";
            this.tabPageOpen.UseVisualStyleBackColor = true;
            // 
            // dataGridViewOpenSalesList
            // 
            this.dataGridViewOpenSalesList.AllowUserToAddRows = false;
            this.dataGridViewOpenSalesList.AllowUserToDeleteRows = false;
            this.dataGridViewOpenSalesList.AllowUserToResizeColumns = false;
            this.dataGridViewOpenSalesList.AllowUserToResizeRows = false;
            dataGridViewCellStyle57.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle57.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewOpenSalesList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle57;
            this.dataGridViewOpenSalesList.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewOpenSalesList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewOpenSalesList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle58.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle58.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle58.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle58.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle58.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewOpenSalesList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle58;
            this.dataGridViewOpenSalesList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOpenSalesList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.TabPageOpenColumnEdit,
            this.TabPageOpenColumnDelete,
            this.TabPageOpenColumnId,
            this.TabPageOpenColumnTerminal,
            this.TabPageOpenColumnSalesDate,
            this.TabPageOpenColumnSalesNumber,
            this.TabPageOpenColumnManualSalesNumber,
            this.TabPageOpenColumnRececiptInvoiceNumber,
            this.TabPageOpenColumnCustomerCode,
            this.TabPageOpenColumnCustomer,
            this.TabPageOpenColumnSalesAgent,
            this.TabPageOpenColumnTable,
            this.TabPageOpenColumnIsLocked,
            this.TabPageOpenColumnIsTendered,
            this.TabPageOpenColumnIsCancelled,
            this.TabPageOpenColumnRemarks,
            this.TabPageOpenColumnDelivery,
            this.TabPageOpenColumnAmount,
            this.TabPageOpenColumnSpace});
            dataGridViewCellStyle64.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle64.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle64.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle64.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle64.SelectionBackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle64.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle64.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewOpenSalesList.DefaultCellStyle = dataGridViewCellStyle64;
            this.dataGridViewOpenSalesList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewOpenSalesList.GridColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridViewOpenSalesList.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewOpenSalesList.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewOpenSalesList.Name = "dataGridViewOpenSalesList";
            this.dataGridViewOpenSalesList.ReadOnly = true;
            this.dataGridViewOpenSalesList.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle65.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle65.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle65.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle65.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle65.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewOpenSalesList.RowHeadersDefaultCellStyle = dataGridViewCellStyle65;
            this.dataGridViewOpenSalesList.RowHeadersVisible = false;
            this.dataGridViewOpenSalesList.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewOpenSalesList.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewOpenSalesList.RowTemplate.Height = 30;
            this.dataGridViewOpenSalesList.RowTemplate.ReadOnly = true;
            this.dataGridViewOpenSalesList.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewOpenSalesList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewOpenSalesList.Size = new System.Drawing.Size(420, 377);
            this.dataGridViewOpenSalesList.TabIndex = 8;
            this.dataGridViewOpenSalesList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewOpenSalesList_CellClick);
            // 
            // TabPageOpenColumnEdit
            // 
            this.TabPageOpenColumnEdit.DataPropertyName = "ColumnEdit";
            this.TabPageOpenColumnEdit.HeaderText = "Edit";
            this.TabPageOpenColumnEdit.Name = "TabPageOpenColumnEdit";
            this.TabPageOpenColumnEdit.ReadOnly = true;
            this.TabPageOpenColumnEdit.Visible = false;
            // 
            // TabPageOpenColumnDelete
            // 
            this.TabPageOpenColumnDelete.DataPropertyName = "ColumnDelete";
            this.TabPageOpenColumnDelete.HeaderText = "Delete";
            this.TabPageOpenColumnDelete.Name = "TabPageOpenColumnDelete";
            this.TabPageOpenColumnDelete.ReadOnly = true;
            this.TabPageOpenColumnDelete.Visible = false;
            // 
            // TabPageOpenColumnId
            // 
            this.TabPageOpenColumnId.DataPropertyName = "ColumnId";
            this.TabPageOpenColumnId.HeaderText = "Id";
            this.TabPageOpenColumnId.Name = "TabPageOpenColumnId";
            this.TabPageOpenColumnId.ReadOnly = true;
            this.TabPageOpenColumnId.Visible = false;
            // 
            // TabPageOpenColumnTerminal
            // 
            this.TabPageOpenColumnTerminal.DataPropertyName = "ColumnTerminal";
            this.TabPageOpenColumnTerminal.HeaderText = "Terminal";
            this.TabPageOpenColumnTerminal.Name = "TabPageOpenColumnTerminal";
            this.TabPageOpenColumnTerminal.ReadOnly = true;
            this.TabPageOpenColumnTerminal.Visible = false;
            // 
            // TabPageOpenColumnSalesDate
            // 
            this.TabPageOpenColumnSalesDate.DataPropertyName = "ColumnSalesDate";
            this.TabPageOpenColumnSalesDate.HeaderText = "SalesDate";
            this.TabPageOpenColumnSalesDate.Name = "TabPageOpenColumnSalesDate";
            this.TabPageOpenColumnSalesDate.ReadOnly = true;
            this.TabPageOpenColumnSalesDate.Visible = false;
            // 
            // TabPageOpenColumnSalesNumber
            // 
            this.TabPageOpenColumnSalesNumber.ActiveLinkColor = System.Drawing.Color.Black;
            this.TabPageOpenColumnSalesNumber.DataPropertyName = "ColumnSalesNumber";
            dataGridViewCellStyle59.Font = new System.Drawing.Font("Segoe UI", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabPageOpenColumnSalesNumber.DefaultCellStyle = dataGridViewCellStyle59;
            this.TabPageOpenColumnSalesNumber.HeaderText = "Order No.";
            this.TabPageOpenColumnSalesNumber.LinkColor = System.Drawing.Color.Black;
            this.TabPageOpenColumnSalesNumber.Name = "TabPageOpenColumnSalesNumber";
            this.TabPageOpenColumnSalesNumber.ReadOnly = true;
            this.TabPageOpenColumnSalesNumber.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.TabPageOpenColumnSalesNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.TabPageOpenColumnSalesNumber.VisitedLinkColor = System.Drawing.Color.Black;
            this.TabPageOpenColumnSalesNumber.Width = 130;
            // 
            // TabPageOpenColumnManualSalesNumber
            // 
            this.TabPageOpenColumnManualSalesNumber.DataPropertyName = "ColumnManualSalesNumber";
            this.TabPageOpenColumnManualSalesNumber.HeaderText = "Manual No.";
            this.TabPageOpenColumnManualSalesNumber.Name = "TabPageOpenColumnManualSalesNumber";
            this.TabPageOpenColumnManualSalesNumber.ReadOnly = true;
            this.TabPageOpenColumnManualSalesNumber.Width = 130;
            // 
            // TabPageOpenColumnRececiptInvoiceNumber
            // 
            this.TabPageOpenColumnRececiptInvoiceNumber.DataPropertyName = "ColumnRececiptInvoiceNumber";
            this.TabPageOpenColumnRececiptInvoiceNumber.HeaderText = "Collection No.";
            this.TabPageOpenColumnRececiptInvoiceNumber.Name = "TabPageOpenColumnRececiptInvoiceNumber";
            this.TabPageOpenColumnRececiptInvoiceNumber.ReadOnly = true;
            this.TabPageOpenColumnRececiptInvoiceNumber.Visible = false;
            this.TabPageOpenColumnRececiptInvoiceNumber.Width = 130;
            // 
            // TabPageOpenColumnCustomerCode
            // 
            this.TabPageOpenColumnCustomerCode.DataPropertyName = "ColumnCustomerCode";
            this.TabPageOpenColumnCustomerCode.HeaderText = "Customer Code";
            this.TabPageOpenColumnCustomerCode.Name = "TabPageOpenColumnCustomerCode";
            this.TabPageOpenColumnCustomerCode.ReadOnly = true;
            this.TabPageOpenColumnCustomerCode.Visible = false;
            // 
            // TabPageOpenColumnCustomer
            // 
            this.TabPageOpenColumnCustomer.DataPropertyName = "ColumnCustomer";
            dataGridViewCellStyle60.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabPageOpenColumnCustomer.DefaultCellStyle = dataGridViewCellStyle60;
            this.TabPageOpenColumnCustomer.HeaderText = "Customer";
            this.TabPageOpenColumnCustomer.Name = "TabPageOpenColumnCustomer";
            this.TabPageOpenColumnCustomer.ReadOnly = true;
            // 
            // TabPageOpenColumnSalesAgent
            // 
            this.TabPageOpenColumnSalesAgent.DataPropertyName = "ColumnSalesAgent";
            dataGridViewCellStyle61.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabPageOpenColumnSalesAgent.DefaultCellStyle = dataGridViewCellStyle61;
            this.TabPageOpenColumnSalesAgent.HeaderText = "User";
            this.TabPageOpenColumnSalesAgent.Name = "TabPageOpenColumnSalesAgent";
            this.TabPageOpenColumnSalesAgent.ReadOnly = true;
            this.TabPageOpenColumnSalesAgent.Width = 130;
            // 
            // TabPageOpenColumnTable
            // 
            this.TabPageOpenColumnTable.DataPropertyName = "ColumnTable";
            dataGridViewCellStyle62.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabPageOpenColumnTable.DefaultCellStyle = dataGridViewCellStyle62;
            this.TabPageOpenColumnTable.HeaderText = "Table";
            this.TabPageOpenColumnTable.Name = "TabPageOpenColumnTable";
            this.TabPageOpenColumnTable.ReadOnly = true;
            // 
            // TabPageOpenColumnIsLocked
            // 
            this.TabPageOpenColumnIsLocked.DataPropertyName = "ColumnIsLocked";
            this.TabPageOpenColumnIsLocked.HeaderText = "L";
            this.TabPageOpenColumnIsLocked.Name = "TabPageOpenColumnIsLocked";
            this.TabPageOpenColumnIsLocked.ReadOnly = true;
            this.TabPageOpenColumnIsLocked.Visible = false;
            // 
            // TabPageOpenColumnIsTendered
            // 
            this.TabPageOpenColumnIsTendered.DataPropertyName = "ColumnIsTendered";
            this.TabPageOpenColumnIsTendered.HeaderText = "T";
            this.TabPageOpenColumnIsTendered.Name = "TabPageOpenColumnIsTendered";
            this.TabPageOpenColumnIsTendered.ReadOnly = true;
            this.TabPageOpenColumnIsTendered.Visible = false;
            // 
            // TabPageOpenColumnIsCancelled
            // 
            this.TabPageOpenColumnIsCancelled.DataPropertyName = "ColumnIsCancelled";
            this.TabPageOpenColumnIsCancelled.HeaderText = "C";
            this.TabPageOpenColumnIsCancelled.Name = "TabPageOpenColumnIsCancelled";
            this.TabPageOpenColumnIsCancelled.ReadOnly = true;
            this.TabPageOpenColumnIsCancelled.Visible = false;
            // 
            // TabPageOpenColumnRemarks
            // 
            this.TabPageOpenColumnRemarks.DataPropertyName = "ColumnRemarks";
            this.TabPageOpenColumnRemarks.HeaderText = "Remarks";
            this.TabPageOpenColumnRemarks.Name = "TabPageOpenColumnRemarks";
            this.TabPageOpenColumnRemarks.ReadOnly = true;
            this.TabPageOpenColumnRemarks.Width = 200;
            // 
            // TabPageOpenColumnDelivery
            // 
            this.TabPageOpenColumnDelivery.DataPropertyName = "ColumnDelivery";
            this.TabPageOpenColumnDelivery.HeaderText = "Delivered By";
            this.TabPageOpenColumnDelivery.Name = "TabPageOpenColumnDelivery";
            this.TabPageOpenColumnDelivery.ReadOnly = true;
            this.TabPageOpenColumnDelivery.Visible = false;
            this.TabPageOpenColumnDelivery.Width = 150;
            // 
            // TabPageOpenColumnAmount
            // 
            this.TabPageOpenColumnAmount.DataPropertyName = "ColumnAmount";
            dataGridViewCellStyle63.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle63.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TabPageOpenColumnAmount.DefaultCellStyle = dataGridViewCellStyle63;
            this.TabPageOpenColumnAmount.HeaderText = "Amount";
            this.TabPageOpenColumnAmount.Name = "TabPageOpenColumnAmount";
            this.TabPageOpenColumnAmount.ReadOnly = true;
            this.TabPageOpenColumnAmount.Width = 120;
            // 
            // TabPageOpenColumnSpace
            // 
            this.TabPageOpenColumnSpace.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.TabPageOpenColumnSpace.DataPropertyName = "ColumnSpace";
            this.TabPageOpenColumnSpace.HeaderText = "";
            this.TabPageOpenColumnSpace.Name = "TabPageOpenColumnSpace";
            this.TabPageOpenColumnSpace.ReadOnly = true;
            this.TabPageOpenColumnSpace.Visible = false;
            // 
            // tabPageBilledOut
            // 
            this.tabPageBilledOut.Controls.Add(this.dataGridViewBilledOutSalesList);
            this.tabPageBilledOut.Location = new System.Drawing.Point(4, 30);
            this.tabPageBilledOut.Margin = new System.Windows.Forms.Padding(0);
            this.tabPageBilledOut.Name = "tabPageBilledOut";
            this.tabPageBilledOut.Size = new System.Drawing.Size(420, 377);
            this.tabPageBilledOut.TabIndex = 1;
            this.tabPageBilledOut.Text = "Billed Out";
            this.tabPageBilledOut.UseVisualStyleBackColor = true;
            // 
            // dataGridViewBilledOutSalesList
            // 
            this.dataGridViewBilledOutSalesList.AllowUserToAddRows = false;
            this.dataGridViewBilledOutSalesList.AllowUserToDeleteRows = false;
            this.dataGridViewBilledOutSalesList.AllowUserToResizeColumns = false;
            this.dataGridViewBilledOutSalesList.AllowUserToResizeRows = false;
            dataGridViewCellStyle66.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle66.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewBilledOutSalesList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle66;
            this.dataGridViewBilledOutSalesList.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewBilledOutSalesList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewBilledOutSalesList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle67.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle67.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle67.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle67.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle67.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewBilledOutSalesList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle67;
            this.dataGridViewBilledOutSalesList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBilledOutSalesList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tabPageBilledOutColumnEdit,
            this.tabPageBilledOutColumnDelete,
            this.tabPageBilledOutColumnId,
            this.tabPageBilledOutColumnTerminal,
            this.tabPageBilledOutColumnSalesDate,
            this.tabPageBilledOutColumnSalesNumber,
            this.tabPageBilledOutColumnManualSalesNumber,
            this.tabPageBilledOutColumnInvoiceNumber,
            this.tabPageBilledOutColumnCustomerCode,
            this.tabPageBilledOutColumnCustomer,
            this.tabPageBilledOutColumnSalesAgent,
            this.tabPageBilledOutColumnTable,
            this.tabPageBilledOutColumnIsLocked,
            this.tabPageBilledOutColumnIsTendered,
            this.tabPageBilledOutColumnIsCancelled,
            this.tabPageBilledOutColumnRemarks,
            this.tabPageBilledOutColumnDelivery,
            this.tabPageBilledOutColumnAmount,
            this.tabPageBilledOutColumnSpace});
            dataGridViewCellStyle73.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle73.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle73.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle73.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle73.SelectionBackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle73.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle73.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewBilledOutSalesList.DefaultCellStyle = dataGridViewCellStyle73;
            this.dataGridViewBilledOutSalesList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewBilledOutSalesList.GridColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridViewBilledOutSalesList.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewBilledOutSalesList.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewBilledOutSalesList.Name = "dataGridViewBilledOutSalesList";
            this.dataGridViewBilledOutSalesList.ReadOnly = true;
            this.dataGridViewBilledOutSalesList.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle74.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle74.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle74.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle74.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle74.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewBilledOutSalesList.RowHeadersDefaultCellStyle = dataGridViewCellStyle74;
            this.dataGridViewBilledOutSalesList.RowHeadersVisible = false;
            this.dataGridViewBilledOutSalesList.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewBilledOutSalesList.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewBilledOutSalesList.RowTemplate.Height = 30;
            this.dataGridViewBilledOutSalesList.RowTemplate.ReadOnly = true;
            this.dataGridViewBilledOutSalesList.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewBilledOutSalesList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewBilledOutSalesList.Size = new System.Drawing.Size(420, 377);
            this.dataGridViewBilledOutSalesList.TabIndex = 9;
            this.dataGridViewBilledOutSalesList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewBilledOutSalesList_CellClick);
            // 
            // tabPageBilledOutColumnEdit
            // 
            this.tabPageBilledOutColumnEdit.DataPropertyName = "ColumnEdit";
            this.tabPageBilledOutColumnEdit.HeaderText = "Edit";
            this.tabPageBilledOutColumnEdit.Name = "tabPageBilledOutColumnEdit";
            this.tabPageBilledOutColumnEdit.ReadOnly = true;
            this.tabPageBilledOutColumnEdit.Visible = false;
            // 
            // tabPageBilledOutColumnDelete
            // 
            this.tabPageBilledOutColumnDelete.DataPropertyName = "ColumnDelete";
            this.tabPageBilledOutColumnDelete.HeaderText = "Delete";
            this.tabPageBilledOutColumnDelete.Name = "tabPageBilledOutColumnDelete";
            this.tabPageBilledOutColumnDelete.ReadOnly = true;
            this.tabPageBilledOutColumnDelete.Visible = false;
            // 
            // tabPageBilledOutColumnId
            // 
            this.tabPageBilledOutColumnId.DataPropertyName = "ColumnId";
            this.tabPageBilledOutColumnId.HeaderText = "Id";
            this.tabPageBilledOutColumnId.Name = "tabPageBilledOutColumnId";
            this.tabPageBilledOutColumnId.ReadOnly = true;
            this.tabPageBilledOutColumnId.Visible = false;
            // 
            // tabPageBilledOutColumnTerminal
            // 
            this.tabPageBilledOutColumnTerminal.DataPropertyName = "ColumnTerminal";
            this.tabPageBilledOutColumnTerminal.HeaderText = "Terminal";
            this.tabPageBilledOutColumnTerminal.Name = "tabPageBilledOutColumnTerminal";
            this.tabPageBilledOutColumnTerminal.ReadOnly = true;
            this.tabPageBilledOutColumnTerminal.Visible = false;
            // 
            // tabPageBilledOutColumnSalesDate
            // 
            this.tabPageBilledOutColumnSalesDate.DataPropertyName = "ColumnSalesDate";
            this.tabPageBilledOutColumnSalesDate.HeaderText = "SalesDate";
            this.tabPageBilledOutColumnSalesDate.Name = "tabPageBilledOutColumnSalesDate";
            this.tabPageBilledOutColumnSalesDate.ReadOnly = true;
            this.tabPageBilledOutColumnSalesDate.Visible = false;
            // 
            // tabPageBilledOutColumnSalesNumber
            // 
            this.tabPageBilledOutColumnSalesNumber.ActiveLinkColor = System.Drawing.Color.Black;
            this.tabPageBilledOutColumnSalesNumber.DataPropertyName = "ColumnSalesNumber";
            dataGridViewCellStyle68.Font = new System.Drawing.Font("Segoe UI", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageBilledOutColumnSalesNumber.DefaultCellStyle = dataGridViewCellStyle68;
            this.tabPageBilledOutColumnSalesNumber.HeaderText = "Order No.";
            this.tabPageBilledOutColumnSalesNumber.LinkColor = System.Drawing.Color.Black;
            this.tabPageBilledOutColumnSalesNumber.Name = "tabPageBilledOutColumnSalesNumber";
            this.tabPageBilledOutColumnSalesNumber.ReadOnly = true;
            this.tabPageBilledOutColumnSalesNumber.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.tabPageBilledOutColumnSalesNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.tabPageBilledOutColumnSalesNumber.VisitedLinkColor = System.Drawing.Color.Black;
            this.tabPageBilledOutColumnSalesNumber.Width = 130;
            // 
            // tabPageBilledOutColumnManualSalesNumber
            // 
            this.tabPageBilledOutColumnManualSalesNumber.DataPropertyName = "ColumnManualSalesNumber";
            this.tabPageBilledOutColumnManualSalesNumber.HeaderText = "Manual No.";
            this.tabPageBilledOutColumnManualSalesNumber.Name = "tabPageBilledOutColumnManualSalesNumber";
            this.tabPageBilledOutColumnManualSalesNumber.ReadOnly = true;
            this.tabPageBilledOutColumnManualSalesNumber.Width = 130;
            // 
            // tabPageBilledOutColumnInvoiceNumber
            // 
            this.tabPageBilledOutColumnInvoiceNumber.DataPropertyName = "ColumnRececiptInvoiceNumber";
            this.tabPageBilledOutColumnInvoiceNumber.HeaderText = "Collection No.";
            this.tabPageBilledOutColumnInvoiceNumber.Name = "tabPageBilledOutColumnInvoiceNumber";
            this.tabPageBilledOutColumnInvoiceNumber.ReadOnly = true;
            this.tabPageBilledOutColumnInvoiceNumber.Visible = false;
            this.tabPageBilledOutColumnInvoiceNumber.Width = 130;
            // 
            // tabPageBilledOutColumnCustomerCode
            // 
            this.tabPageBilledOutColumnCustomerCode.DataPropertyName = "ColumnCustomerCode";
            this.tabPageBilledOutColumnCustomerCode.HeaderText = "Customer Code";
            this.tabPageBilledOutColumnCustomerCode.Name = "tabPageBilledOutColumnCustomerCode";
            this.tabPageBilledOutColumnCustomerCode.ReadOnly = true;
            this.tabPageBilledOutColumnCustomerCode.Visible = false;
            // 
            // tabPageBilledOutColumnCustomer
            // 
            this.tabPageBilledOutColumnCustomer.DataPropertyName = "ColumnCustomer";
            dataGridViewCellStyle69.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageBilledOutColumnCustomer.DefaultCellStyle = dataGridViewCellStyle69;
            this.tabPageBilledOutColumnCustomer.HeaderText = "Customer";
            this.tabPageBilledOutColumnCustomer.Name = "tabPageBilledOutColumnCustomer";
            this.tabPageBilledOutColumnCustomer.ReadOnly = true;
            // 
            // tabPageBilledOutColumnSalesAgent
            // 
            this.tabPageBilledOutColumnSalesAgent.DataPropertyName = "ColumnSalesAgent";
            dataGridViewCellStyle70.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageBilledOutColumnSalesAgent.DefaultCellStyle = dataGridViewCellStyle70;
            this.tabPageBilledOutColumnSalesAgent.HeaderText = "User";
            this.tabPageBilledOutColumnSalesAgent.Name = "tabPageBilledOutColumnSalesAgent";
            this.tabPageBilledOutColumnSalesAgent.ReadOnly = true;
            this.tabPageBilledOutColumnSalesAgent.Width = 130;
            // 
            // tabPageBilledOutColumnTable
            // 
            this.tabPageBilledOutColumnTable.DataPropertyName = "ColumnTable";
            dataGridViewCellStyle71.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageBilledOutColumnTable.DefaultCellStyle = dataGridViewCellStyle71;
            this.tabPageBilledOutColumnTable.HeaderText = "Table";
            this.tabPageBilledOutColumnTable.Name = "tabPageBilledOutColumnTable";
            this.tabPageBilledOutColumnTable.ReadOnly = true;
            // 
            // tabPageBilledOutColumnIsLocked
            // 
            this.tabPageBilledOutColumnIsLocked.DataPropertyName = "ColumnIsLocked";
            this.tabPageBilledOutColumnIsLocked.HeaderText = "L";
            this.tabPageBilledOutColumnIsLocked.Name = "tabPageBilledOutColumnIsLocked";
            this.tabPageBilledOutColumnIsLocked.ReadOnly = true;
            this.tabPageBilledOutColumnIsLocked.Visible = false;
            // 
            // tabPageBilledOutColumnIsTendered
            // 
            this.tabPageBilledOutColumnIsTendered.DataPropertyName = "ColumnIsTendered";
            this.tabPageBilledOutColumnIsTendered.HeaderText = "T";
            this.tabPageBilledOutColumnIsTendered.Name = "tabPageBilledOutColumnIsTendered";
            this.tabPageBilledOutColumnIsTendered.ReadOnly = true;
            this.tabPageBilledOutColumnIsTendered.Visible = false;
            // 
            // tabPageBilledOutColumnIsCancelled
            // 
            this.tabPageBilledOutColumnIsCancelled.DataPropertyName = "ColumnIsCancelled";
            this.tabPageBilledOutColumnIsCancelled.HeaderText = "C";
            this.tabPageBilledOutColumnIsCancelled.Name = "tabPageBilledOutColumnIsCancelled";
            this.tabPageBilledOutColumnIsCancelled.ReadOnly = true;
            this.tabPageBilledOutColumnIsCancelled.Visible = false;
            // 
            // tabPageBilledOutColumnRemarks
            // 
            this.tabPageBilledOutColumnRemarks.DataPropertyName = "ColumnRemarks";
            this.tabPageBilledOutColumnRemarks.HeaderText = "Remarks";
            this.tabPageBilledOutColumnRemarks.Name = "tabPageBilledOutColumnRemarks";
            this.tabPageBilledOutColumnRemarks.ReadOnly = true;
            this.tabPageBilledOutColumnRemarks.Width = 200;
            // 
            // tabPageBilledOutColumnDelivery
            // 
            this.tabPageBilledOutColumnDelivery.DataPropertyName = "ColumnDelivery";
            this.tabPageBilledOutColumnDelivery.HeaderText = "Delivered By";
            this.tabPageBilledOutColumnDelivery.Name = "tabPageBilledOutColumnDelivery";
            this.tabPageBilledOutColumnDelivery.ReadOnly = true;
            this.tabPageBilledOutColumnDelivery.Width = 150;
            // 
            // tabPageBilledOutColumnAmount
            // 
            this.tabPageBilledOutColumnAmount.DataPropertyName = "ColumnAmount";
            dataGridViewCellStyle72.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle72.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageBilledOutColumnAmount.DefaultCellStyle = dataGridViewCellStyle72;
            this.tabPageBilledOutColumnAmount.HeaderText = "Amount";
            this.tabPageBilledOutColumnAmount.Name = "tabPageBilledOutColumnAmount";
            this.tabPageBilledOutColumnAmount.ReadOnly = true;
            this.tabPageBilledOutColumnAmount.Width = 120;
            // 
            // tabPageBilledOutColumnSpace
            // 
            this.tabPageBilledOutColumnSpace.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.tabPageBilledOutColumnSpace.DataPropertyName = "ColumnSpace";
            this.tabPageBilledOutColumnSpace.HeaderText = "";
            this.tabPageBilledOutColumnSpace.Name = "tabPageBilledOutColumnSpace";
            this.tabPageBilledOutColumnSpace.ReadOnly = true;
            this.tabPageBilledOutColumnSpace.Visible = false;
            // 
            // tabPageCollected
            // 
            this.tabPageCollected.Controls.Add(this.dataGridViewCollectedSalesList);
            this.tabPageCollected.Location = new System.Drawing.Point(4, 30);
            this.tabPageCollected.Margin = new System.Windows.Forms.Padding(0);
            this.tabPageCollected.Name = "tabPageCollected";
            this.tabPageCollected.Size = new System.Drawing.Size(420, 377);
            this.tabPageCollected.TabIndex = 2;
            this.tabPageCollected.Text = "Collected";
            this.tabPageCollected.UseVisualStyleBackColor = true;
            // 
            // dataGridViewCollectedSalesList
            // 
            this.dataGridViewCollectedSalesList.AllowUserToAddRows = false;
            this.dataGridViewCollectedSalesList.AllowUserToDeleteRows = false;
            this.dataGridViewCollectedSalesList.AllowUserToResizeColumns = false;
            this.dataGridViewCollectedSalesList.AllowUserToResizeRows = false;
            dataGridViewCellStyle75.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle75.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewCollectedSalesList.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle75;
            this.dataGridViewCollectedSalesList.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewCollectedSalesList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewCollectedSalesList.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle76.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle76.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle76.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle76.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle76.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCollectedSalesList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle76;
            this.dataGridViewCollectedSalesList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCollectedSalesList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tabPageCollectedColumnEdit,
            this.tabPageCollectedColumnDelete,
            this.tabPageCollectedColumnId,
            this.tabPageCollectedColumnTerminal,
            this.tabPageCollectedColumnSalesDate,
            this.tabPageCollectedColumnSalesNumber,
            this.tabPageCollectedColumnManualSalesNumber,
            this.tabPageCollectedColumnCollectionNumber,
            this.tabPageCollectedColumnCustomerCode,
            this.tabPageCollectedColumnCustomer,
            this.tabPageCollectedColumnSalesAgent,
            this.tabPageCollectedColumnTable,
            this.tabPageCollectedColumnIsLocked,
            this.tabPageCollectedColumnIsTendered,
            this.tabPageCollectedColumnIsCancelled,
            this.tabPageCollectedColumnRemarks,
            this.tabPageCollectedColumnDelivery,
            this.tabPageCollectedColumnAmount,
            this.tabPageCollectedColumnSpace});
            dataGridViewCellStyle83.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle83.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle83.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle83.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle83.SelectionBackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle83.SelectionForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle83.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCollectedSalesList.DefaultCellStyle = dataGridViewCellStyle83;
            this.dataGridViewCollectedSalesList.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridViewCollectedSalesList.GridColor = System.Drawing.SystemColors.ControlLight;
            this.dataGridViewCollectedSalesList.Location = new System.Drawing.Point(0, 0);
            this.dataGridViewCollectedSalesList.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewCollectedSalesList.Name = "dataGridViewCollectedSalesList";
            this.dataGridViewCollectedSalesList.ReadOnly = true;
            this.dataGridViewCollectedSalesList.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle84.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle84.Font = new System.Drawing.Font("Segoe UI", 12F);
            dataGridViewCellStyle84.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle84.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle84.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewCollectedSalesList.RowHeadersDefaultCellStyle = dataGridViewCellStyle84;
            this.dataGridViewCollectedSalesList.RowHeadersVisible = false;
            this.dataGridViewCollectedSalesList.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.dataGridViewCollectedSalesList.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.dataGridViewCollectedSalesList.RowTemplate.Height = 30;
            this.dataGridViewCollectedSalesList.RowTemplate.ReadOnly = true;
            this.dataGridViewCollectedSalesList.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewCollectedSalesList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewCollectedSalesList.Size = new System.Drawing.Size(420, 377);
            this.dataGridViewCollectedSalesList.TabIndex = 10;
            this.dataGridViewCollectedSalesList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewCollectedSalesList_CellClick);
            // 
            // tabPageCollectedColumnEdit
            // 
            this.tabPageCollectedColumnEdit.DataPropertyName = "ColumnEdit";
            this.tabPageCollectedColumnEdit.HeaderText = "Edit";
            this.tabPageCollectedColumnEdit.Name = "tabPageCollectedColumnEdit";
            this.tabPageCollectedColumnEdit.ReadOnly = true;
            this.tabPageCollectedColumnEdit.Visible = false;
            // 
            // tabPageCollectedColumnDelete
            // 
            this.tabPageCollectedColumnDelete.DataPropertyName = "ColumnDelete";
            this.tabPageCollectedColumnDelete.HeaderText = "Delete";
            this.tabPageCollectedColumnDelete.Name = "tabPageCollectedColumnDelete";
            this.tabPageCollectedColumnDelete.ReadOnly = true;
            this.tabPageCollectedColumnDelete.Visible = false;
            // 
            // tabPageCollectedColumnId
            // 
            this.tabPageCollectedColumnId.DataPropertyName = "ColumnId";
            this.tabPageCollectedColumnId.HeaderText = "Id";
            this.tabPageCollectedColumnId.Name = "tabPageCollectedColumnId";
            this.tabPageCollectedColumnId.ReadOnly = true;
            this.tabPageCollectedColumnId.Visible = false;
            // 
            // tabPageCollectedColumnTerminal
            // 
            this.tabPageCollectedColumnTerminal.DataPropertyName = "ColumnTerminal";
            this.tabPageCollectedColumnTerminal.HeaderText = "Terminal";
            this.tabPageCollectedColumnTerminal.Name = "tabPageCollectedColumnTerminal";
            this.tabPageCollectedColumnTerminal.ReadOnly = true;
            this.tabPageCollectedColumnTerminal.Visible = false;
            // 
            // tabPageCollectedColumnSalesDate
            // 
            this.tabPageCollectedColumnSalesDate.DataPropertyName = "ColumnSalesDate";
            this.tabPageCollectedColumnSalesDate.HeaderText = "SalesDate";
            this.tabPageCollectedColumnSalesDate.Name = "tabPageCollectedColumnSalesDate";
            this.tabPageCollectedColumnSalesDate.ReadOnly = true;
            this.tabPageCollectedColumnSalesDate.Visible = false;
            // 
            // tabPageCollectedColumnSalesNumber
            // 
            this.tabPageCollectedColumnSalesNumber.ActiveLinkColor = System.Drawing.Color.Black;
            this.tabPageCollectedColumnSalesNumber.DataPropertyName = "ColumnSalesNumber";
            dataGridViewCellStyle77.Font = new System.Drawing.Font("Segoe UI", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageCollectedColumnSalesNumber.DefaultCellStyle = dataGridViewCellStyle77;
            this.tabPageCollectedColumnSalesNumber.HeaderText = "Order No.";
            this.tabPageCollectedColumnSalesNumber.LinkColor = System.Drawing.Color.Black;
            this.tabPageCollectedColumnSalesNumber.Name = "tabPageCollectedColumnSalesNumber";
            this.tabPageCollectedColumnSalesNumber.ReadOnly = true;
            this.tabPageCollectedColumnSalesNumber.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.tabPageCollectedColumnSalesNumber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.tabPageCollectedColumnSalesNumber.VisitedLinkColor = System.Drawing.Color.Black;
            this.tabPageCollectedColumnSalesNumber.Width = 130;
            // 
            // tabPageCollectedColumnManualSalesNumber
            // 
            this.tabPageCollectedColumnManualSalesNumber.DataPropertyName = "ColumnManualSalesNumber";
            this.tabPageCollectedColumnManualSalesNumber.HeaderText = "Manual No.";
            this.tabPageCollectedColumnManualSalesNumber.Name = "tabPageCollectedColumnManualSalesNumber";
            this.tabPageCollectedColumnManualSalesNumber.ReadOnly = true;
            this.tabPageCollectedColumnManualSalesNumber.Width = 130;
            // 
            // tabPageCollectedColumnCollectionNumber
            // 
            this.tabPageCollectedColumnCollectionNumber.DataPropertyName = "ColumnRececiptInvoiceNumber";
            dataGridViewCellStyle78.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.tabPageCollectedColumnCollectionNumber.DefaultCellStyle = dataGridViewCellStyle78;
            this.tabPageCollectedColumnCollectionNumber.HeaderText = "Collection No.";
            this.tabPageCollectedColumnCollectionNumber.Name = "tabPageCollectedColumnCollectionNumber";
            this.tabPageCollectedColumnCollectionNumber.ReadOnly = true;
            this.tabPageCollectedColumnCollectionNumber.Width = 130;
            // 
            // tabPageCollectedColumnCustomerCode
            // 
            this.tabPageCollectedColumnCustomerCode.DataPropertyName = "ColumnCustomerCode";
            this.tabPageCollectedColumnCustomerCode.HeaderText = "Customer Code";
            this.tabPageCollectedColumnCustomerCode.Name = "tabPageCollectedColumnCustomerCode";
            this.tabPageCollectedColumnCustomerCode.ReadOnly = true;
            this.tabPageCollectedColumnCustomerCode.Visible = false;
            // 
            // tabPageCollectedColumnCustomer
            // 
            this.tabPageCollectedColumnCustomer.DataPropertyName = "ColumnCustomer";
            dataGridViewCellStyle79.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageCollectedColumnCustomer.DefaultCellStyle = dataGridViewCellStyle79;
            this.tabPageCollectedColumnCustomer.HeaderText = "Customer";
            this.tabPageCollectedColumnCustomer.Name = "tabPageCollectedColumnCustomer";
            this.tabPageCollectedColumnCustomer.ReadOnly = true;
            // 
            // tabPageCollectedColumnSalesAgent
            // 
            this.tabPageCollectedColumnSalesAgent.DataPropertyName = "ColumnSalesAgent";
            dataGridViewCellStyle80.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageCollectedColumnSalesAgent.DefaultCellStyle = dataGridViewCellStyle80;
            this.tabPageCollectedColumnSalesAgent.HeaderText = "User";
            this.tabPageCollectedColumnSalesAgent.Name = "tabPageCollectedColumnSalesAgent";
            this.tabPageCollectedColumnSalesAgent.ReadOnly = true;
            this.tabPageCollectedColumnSalesAgent.Width = 130;
            // 
            // tabPageCollectedColumnTable
            // 
            this.tabPageCollectedColumnTable.DataPropertyName = "ColumnTable";
            dataGridViewCellStyle81.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageCollectedColumnTable.DefaultCellStyle = dataGridViewCellStyle81;
            this.tabPageCollectedColumnTable.HeaderText = "Table";
            this.tabPageCollectedColumnTable.Name = "tabPageCollectedColumnTable";
            this.tabPageCollectedColumnTable.ReadOnly = true;
            // 
            // tabPageCollectedColumnIsLocked
            // 
            this.tabPageCollectedColumnIsLocked.DataPropertyName = "ColumnIsLocked";
            this.tabPageCollectedColumnIsLocked.HeaderText = "L";
            this.tabPageCollectedColumnIsLocked.Name = "tabPageCollectedColumnIsLocked";
            this.tabPageCollectedColumnIsLocked.ReadOnly = true;
            this.tabPageCollectedColumnIsLocked.Visible = false;
            // 
            // tabPageCollectedColumnIsTendered
            // 
            this.tabPageCollectedColumnIsTendered.DataPropertyName = "ColumnIsTendered";
            this.tabPageCollectedColumnIsTendered.HeaderText = "T";
            this.tabPageCollectedColumnIsTendered.Name = "tabPageCollectedColumnIsTendered";
            this.tabPageCollectedColumnIsTendered.ReadOnly = true;
            this.tabPageCollectedColumnIsTendered.Visible = false;
            // 
            // tabPageCollectedColumnIsCancelled
            // 
            this.tabPageCollectedColumnIsCancelled.DataPropertyName = "ColumnIsCancelled";
            this.tabPageCollectedColumnIsCancelled.HeaderText = "C";
            this.tabPageCollectedColumnIsCancelled.Name = "tabPageCollectedColumnIsCancelled";
            this.tabPageCollectedColumnIsCancelled.ReadOnly = true;
            this.tabPageCollectedColumnIsCancelled.Width = 50;
            // 
            // tabPageCollectedColumnRemarks
            // 
            this.tabPageCollectedColumnRemarks.DataPropertyName = "ColumnRemarks";
            this.tabPageCollectedColumnRemarks.HeaderText = "Remarks";
            this.tabPageCollectedColumnRemarks.Name = "tabPageCollectedColumnRemarks";
            this.tabPageCollectedColumnRemarks.ReadOnly = true;
            this.tabPageCollectedColumnRemarks.Width = 200;
            // 
            // tabPageCollectedColumnDelivery
            // 
            this.tabPageCollectedColumnDelivery.DataPropertyName = "ColumnDelivery";
            this.tabPageCollectedColumnDelivery.HeaderText = "Delivered By";
            this.tabPageCollectedColumnDelivery.Name = "tabPageCollectedColumnDelivery";
            this.tabPageCollectedColumnDelivery.ReadOnly = true;
            this.tabPageCollectedColumnDelivery.Width = 150;
            // 
            // tabPageCollectedColumnAmount
            // 
            this.tabPageCollectedColumnAmount.DataPropertyName = "ColumnAmount";
            dataGridViewCellStyle82.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle82.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabPageCollectedColumnAmount.DefaultCellStyle = dataGridViewCellStyle82;
            this.tabPageCollectedColumnAmount.HeaderText = "Amount";
            this.tabPageCollectedColumnAmount.Name = "tabPageCollectedColumnAmount";
            this.tabPageCollectedColumnAmount.ReadOnly = true;
            this.tabPageCollectedColumnAmount.Width = 120;
            // 
            // tabPageCollectedColumnSpace
            // 
            this.tabPageCollectedColumnSpace.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.tabPageCollectedColumnSpace.DataPropertyName = "ColumnSpace";
            this.tabPageCollectedColumnSpace.HeaderText = "";
            this.tabPageCollectedColumnSpace.Name = "tabPageCollectedColumnSpace";
            this.tabPageCollectedColumnSpace.ReadOnly = true;
            this.tabPageCollectedColumnSpace.Visible = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel9);
            this.panel2.Controls.Add(this.panel10);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(668, 411);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(428, 100);
            this.panel2.TabIndex = 16;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel7);
            this.panel9.Controls.Add(this.buttonTenderAll);
            this.panel9.Controls.Add(this.panel8);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(53, 0);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(375, 100);
            this.panel9.TabIndex = 54;
            // 
            // panel7
            // 
            this.panel7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel7.BackColor = System.Drawing.Color.White;
            this.panel7.Controls.Add(this.textBoxTotalAmount);
            this.panel7.Controls.Add(this.label2);
            this.panel7.Location = new System.Drawing.Point(3, 6);
            this.panel7.Margin = new System.Windows.Forms.Padding(2);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(269, 42);
            this.panel7.TabIndex = 58;
            // 
            // textBoxTotalAmount
            // 
            this.textBoxTotalAmount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTotalAmount.BackColor = System.Drawing.Color.White;
            this.textBoxTotalAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTotalAmount.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.textBoxTotalAmount.ForeColor = System.Drawing.Color.Black;
            this.textBoxTotalAmount.Location = new System.Drawing.Point(124, 6);
            this.textBoxTotalAmount.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxTotalAmount.Name = "textBoxTotalAmount";
            this.textBoxTotalAmount.ReadOnly = true;
            this.textBoxTotalAmount.Size = new System.Drawing.Size(135, 27);
            this.textBoxTotalAmount.TabIndex = 17;
            this.textBoxTotalAmount.Text = "0.00";
            this.textBoxTotalAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(10, 11);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 20);
            this.label2.TabIndex = 16;
            this.label2.Text = "Total Amount:";
            // 
            // buttonTenderAll
            // 
            this.buttonTenderAll.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonTenderAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonTenderAll.FlatAppearance.BorderSize = 0;
            this.buttonTenderAll.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTenderAll.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTenderAll.Location = new System.Drawing.Point(276, 6);
            this.buttonTenderAll.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTenderAll.Name = "buttonTenderAll";
            this.buttonTenderAll.Size = new System.Drawing.Size(96, 88);
            this.buttonTenderAll.TabIndex = 59;
            this.buttonTenderAll.Text = "Tender All";
            this.buttonTenderAll.UseVisualStyleBackColor = false;
            this.buttonTenderAll.Click += new System.EventHandler(this.buttonTenderAll_Click);
            // 
            // panel8
            // 
            this.panel8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Controls.Add(this.textBoxLastChange);
            this.panel8.Controls.Add(this.labelLastChange);
            this.panel8.Location = new System.Drawing.Point(3, 52);
            this.panel8.Margin = new System.Windows.Forms.Padding(2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(269, 42);
            this.panel8.TabIndex = 57;
            // 
            // textBoxLastChange
            // 
            this.textBoxLastChange.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxLastChange.BackColor = System.Drawing.Color.White;
            this.textBoxLastChange.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxLastChange.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.textBoxLastChange.ForeColor = System.Drawing.Color.Black;
            this.textBoxLastChange.Location = new System.Drawing.Point(124, 6);
            this.textBoxLastChange.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxLastChange.Name = "textBoxLastChange";
            this.textBoxLastChange.ReadOnly = true;
            this.textBoxLastChange.Size = new System.Drawing.Size(135, 27);
            this.textBoxLastChange.TabIndex = 17;
            this.textBoxLastChange.Text = "0.00";
            this.textBoxLastChange.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelLastChange
            // 
            this.labelLastChange.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.labelLastChange.AutoSize = true;
            this.labelLastChange.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.labelLastChange.ForeColor = System.Drawing.Color.Black;
            this.labelLastChange.Location = new System.Drawing.Point(10, 11);
            this.labelLastChange.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLastChange.Name = "labelLastChange";
            this.labelLastChange.Size = new System.Drawing.Size(98, 20);
            this.labelLastChange.TabIndex = 16;
            this.labelLastChange.Text = "Last Change:";
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.buttonHideItems);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel10.Location = new System.Drawing.Point(0, 0);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(53, 100);
            this.panel10.TabIndex = 28;
            // 
            // buttonHideItems
            // 
            this.buttonHideItems.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.buttonHideItems.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(34)))), ((int)(((byte)(116)))));
            this.buttonHideItems.FlatAppearance.BorderSize = 0;
            this.buttonHideItems.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHideItems.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.buttonHideItems.ForeColor = System.Drawing.Color.White;
            this.buttonHideItems.Location = new System.Drawing.Point(2, 6);
            this.buttonHideItems.Margin = new System.Windows.Forms.Padding(2);
            this.buttonHideItems.Name = "buttonHideItems";
            this.buttonHideItems.Size = new System.Drawing.Size(48, 87);
            this.buttonHideItems.TabIndex = 26;
            this.buttonHideItems.TabStop = false;
            this.buttonHideItems.Text = "<";
            this.buttonHideItems.UseVisualStyleBackColor = false;
            this.buttonHideItems.Click += new System.EventHandler(this.buttonHideItems_Click);
            // 
            // panelWalkIn
            // 
            this.panelWalkIn.Controls.Add(this.textBoxFilter);
            this.panelWalkIn.Controls.Add(this.comboBoxTerminal);
            this.panelWalkIn.Controls.Add(this.dateTimePickerSalesDate);
            this.panelWalkIn.Controls.Add(this.panel6);
            this.panelWalkIn.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelWalkIn.Location = new System.Drawing.Point(0, 0);
            this.panelWalkIn.Name = "panelWalkIn";
            this.panelWalkIn.Size = new System.Drawing.Size(668, 511);
            this.panelWalkIn.TabIndex = 16;
            // 
            // textBoxFilter
            // 
            this.textBoxFilter.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.textBoxFilter.Location = new System.Drawing.Point(277, 6);
            this.textBoxFilter.Name = "textBoxFilter";
            this.textBoxFilter.Size = new System.Drawing.Size(388, 29);
            this.textBoxFilter.TabIndex = 23;
            // 
            // comboBoxTerminal
            // 
            this.comboBoxTerminal.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.comboBoxTerminal.FormattingEnabled = true;
            this.comboBoxTerminal.Location = new System.Drawing.Point(132, 6);
            this.comboBoxTerminal.Margin = new System.Windows.Forms.Padding(2);
            this.comboBoxTerminal.Name = "comboBoxTerminal";
            this.comboBoxTerminal.Size = new System.Drawing.Size(140, 29);
            this.comboBoxTerminal.TabIndex = 21;
            this.comboBoxTerminal.SelectedIndexChanged += new System.EventHandler(this.comboBoxTerminal_SelectedIndexChanged);
            // 
            // dateTimePickerSalesDate
            // 
            this.dateTimePickerSalesDate.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.dateTimePickerSalesDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePickerSalesDate.Location = new System.Drawing.Point(3, 6);
            this.dateTimePickerSalesDate.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePickerSalesDate.Name = "dateTimePickerSalesDate";
            this.dateTimePickerSalesDate.Size = new System.Drawing.Size(126, 29);
            this.dateTimePickerSalesDate.TabIndex = 22;
            this.dateTimePickerSalesDate.ValueChanged += new System.EventHandler(this.dateTimePickerSalesDate_ValueChanged);
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel6.BackColor = System.Drawing.Color.White;
            this.panel6.Controls.Add(this.buttonDelivery);
            this.panel6.Controls.Add(this.buttonWalkIn);
            this.panel6.Controls.Add(this.buttonTableGroup4);
            this.panel6.Controls.Add(this.buttonTableGroup5);
            this.panel6.Controls.Add(this.buttonTableGroup6);
            this.panel6.Controls.Add(this.buttonTableGroup1);
            this.panel6.Controls.Add(this.buttonTableGroup2);
            this.panel6.Controls.Add(this.buttonTableGroup3);
            this.panel6.Controls.Add(this.buttonTable4);
            this.panel6.Controls.Add(this.buttonTable5);
            this.panel6.Controls.Add(this.buttonTable6);
            this.panel6.Controls.Add(this.buttonTable10);
            this.panel6.Controls.Add(this.buttonTable11);
            this.panel6.Controls.Add(this.buttonTable12);
            this.panel6.Controls.Add(this.buttonTable16);
            this.panel6.Controls.Add(this.buttonTable17);
            this.panel6.Controls.Add(this.buttonTable18);
            this.panel6.Controls.Add(this.buttonTable22);
            this.panel6.Controls.Add(this.buttonTable23);
            this.panel6.Controls.Add(this.buttonTable24);
            this.panel6.Controls.Add(this.buttonTable1);
            this.panel6.Controls.Add(this.buttonTable2);
            this.panel6.Controls.Add(this.buttonTable3);
            this.panel6.Controls.Add(this.buttonTable7);
            this.panel6.Controls.Add(this.buttonTable8);
            this.panel6.Controls.Add(this.buttonTable9);
            this.panel6.Controls.Add(this.buttonTable13);
            this.panel6.Controls.Add(this.buttonTable14);
            this.panel6.Controls.Add(this.buttonTable15);
            this.panel6.Controls.Add(this.buttonTable19);
            this.panel6.Controls.Add(this.buttonTable20);
            this.panel6.Controls.Add(this.buttonTable21);
            this.panel6.Controls.Add(this.buttonTable28);
            this.panel6.Controls.Add(this.buttonTable29);
            this.panel6.Controls.Add(this.buttonTable30);
            this.panel6.Controls.Add(this.buttonTable25);
            this.panel6.Controls.Add(this.buttonTable26);
            this.panel6.Controls.Add(this.buttonTable27);
            this.panel6.Controls.Add(this.buttonTableNext);
            this.panel6.Controls.Add(this.buttonTableGroupPageNext);
            this.panel6.Controls.Add(this.buttonTablePrevious);
            this.panel6.Controls.Add(this.buttonTableGroupPagePrevious);
            this.panel6.Location = new System.Drawing.Point(3, 38);
            this.panel6.Margin = new System.Windows.Forms.Padding(2);
            this.panel6.Name = "panel6";
            this.panel6.Padding = new System.Windows.Forms.Padding(4);
            this.panel6.Size = new System.Drawing.Size(662, 466);
            this.panel6.TabIndex = 24;
            // 
            // buttonDelivery
            // 
            this.buttonDelivery.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonDelivery.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.buttonDelivery.FlatAppearance.BorderSize = 0;
            this.buttonDelivery.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDelivery.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.buttonDelivery.ForeColor = System.Drawing.Color.White;
            this.buttonDelivery.ImageIndex = 0;
            this.buttonDelivery.ImageList = this.imageListPOSTouch;
            this.buttonDelivery.Location = new System.Drawing.Point(334, 393);
            this.buttonDelivery.Margin = new System.Windows.Forms.Padding(2);
            this.buttonDelivery.Name = "buttonDelivery";
            this.buttonDelivery.Size = new System.Drawing.Size(322, 67);
            this.buttonDelivery.TabIndex = 45;
            this.buttonDelivery.Text = "\r\nDelivery";
            this.buttonDelivery.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonDelivery.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttonDelivery.UseVisualStyleBackColor = false;
            this.buttonDelivery.Click += new System.EventHandler(this.buttonDelivery_Click);
            // 
            // buttonWalkIn
            // 
            this.buttonWalkIn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonWalkIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.buttonWalkIn.FlatAppearance.BorderSize = 0;
            this.buttonWalkIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonWalkIn.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.buttonWalkIn.ForeColor = System.Drawing.Color.White;
            this.buttonWalkIn.ImageIndex = 1;
            this.buttonWalkIn.ImageList = this.imageListPOSTouch;
            this.buttonWalkIn.Location = new System.Drawing.Point(7, 393);
            this.buttonWalkIn.Margin = new System.Windows.Forms.Padding(2);
            this.buttonWalkIn.Name = "buttonWalkIn";
            this.buttonWalkIn.Size = new System.Drawing.Size(322, 67);
            this.buttonWalkIn.TabIndex = 44;
            this.buttonWalkIn.Text = "\r\nWalk In";
            this.buttonWalkIn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonWalkIn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttonWalkIn.UseVisualStyleBackColor = false;
            this.buttonWalkIn.Click += new System.EventHandler(this.buttonWalkIn_Click);
            // 
            // buttonTableGroup4
            // 
            this.buttonTableGroup4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonTableGroup4.FlatAppearance.BorderSize = 0;
            this.buttonTableGroup4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTableGroup4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTableGroup4.Location = new System.Drawing.Point(334, 6);
            this.buttonTableGroup4.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTableGroup4.Name = "buttonTableGroup4";
            this.buttonTableGroup4.Size = new System.Drawing.Size(85, 50);
            this.buttonTableGroup4.TabIndex = 41;
            this.buttonTableGroup4.UseVisualStyleBackColor = false;
            this.buttonTableGroup4.Click += new System.EventHandler(this.buttonTableGroup4_Click);
            // 
            // buttonTableGroup5
            // 
            this.buttonTableGroup5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonTableGroup5.FlatAppearance.BorderSize = 0;
            this.buttonTableGroup5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTableGroup5.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTableGroup5.Location = new System.Drawing.Point(423, 6);
            this.buttonTableGroup5.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTableGroup5.Name = "buttonTableGroup5";
            this.buttonTableGroup5.Size = new System.Drawing.Size(85, 50);
            this.buttonTableGroup5.TabIndex = 40;
            this.buttonTableGroup5.UseVisualStyleBackColor = false;
            this.buttonTableGroup5.Click += new System.EventHandler(this.buttonTableGroup5_Click);
            // 
            // buttonTableGroup6
            // 
            this.buttonTableGroup6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonTableGroup6.FlatAppearance.BorderSize = 0;
            this.buttonTableGroup6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTableGroup6.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTableGroup6.Location = new System.Drawing.Point(513, 6);
            this.buttonTableGroup6.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTableGroup6.Name = "buttonTableGroup6";
            this.buttonTableGroup6.Size = new System.Drawing.Size(86, 50);
            this.buttonTableGroup6.TabIndex = 39;
            this.buttonTableGroup6.UseVisualStyleBackColor = false;
            this.buttonTableGroup6.Click += new System.EventHandler(this.buttonTableGroup6_Click);
            // 
            // buttonTableGroup1
            // 
            this.buttonTableGroup1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonTableGroup1.FlatAppearance.BorderSize = 0;
            this.buttonTableGroup1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTableGroup1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTableGroup1.Location = new System.Drawing.Point(63, 6);
            this.buttonTableGroup1.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTableGroup1.Name = "buttonTableGroup1";
            this.buttonTableGroup1.Size = new System.Drawing.Size(86, 50);
            this.buttonTableGroup1.TabIndex = 38;
            this.buttonTableGroup1.UseVisualStyleBackColor = false;
            this.buttonTableGroup1.Click += new System.EventHandler(this.buttonTableGroup1_Click);
            // 
            // buttonTableGroup2
            // 
            this.buttonTableGroup2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonTableGroup2.FlatAppearance.BorderSize = 0;
            this.buttonTableGroup2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTableGroup2.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTableGroup2.Location = new System.Drawing.Point(154, 6);
            this.buttonTableGroup2.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTableGroup2.Name = "buttonTableGroup2";
            this.buttonTableGroup2.Size = new System.Drawing.Size(86, 50);
            this.buttonTableGroup2.TabIndex = 37;
            this.buttonTableGroup2.UseVisualStyleBackColor = false;
            this.buttonTableGroup2.Click += new System.EventHandler(this.buttonTableGroup2_Click);
            // 
            // buttonTableGroup3
            // 
            this.buttonTableGroup3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonTableGroup3.FlatAppearance.BorderSize = 0;
            this.buttonTableGroup3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTableGroup3.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTableGroup3.Location = new System.Drawing.Point(244, 6);
            this.buttonTableGroup3.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTableGroup3.Name = "buttonTableGroup3";
            this.buttonTableGroup3.Size = new System.Drawing.Size(85, 50);
            this.buttonTableGroup3.TabIndex = 36;
            this.buttonTableGroup3.UseVisualStyleBackColor = false;
            this.buttonTableGroup3.Click += new System.EventHandler(this.buttonTableGroup3_Click);
            // 
            // buttonTable4
            // 
            this.buttonTable4.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable4.FlatAppearance.BorderSize = 0;
            this.buttonTable4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable4.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable4.ForeColor = System.Drawing.Color.Black;
            this.buttonTable4.Location = new System.Drawing.Point(334, 61);
            this.buttonTable4.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable4.Name = "buttonTable4";
            this.buttonTable4.Size = new System.Drawing.Size(86, 62);
            this.buttonTable4.TabIndex = 35;
            this.buttonTable4.UseVisualStyleBackColor = false;
            // 
            // buttonTable5
            // 
            this.buttonTable5.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable5.FlatAppearance.BorderSize = 0;
            this.buttonTable5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable5.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable5.ForeColor = System.Drawing.Color.Black;
            this.buttonTable5.Location = new System.Drawing.Point(423, 61);
            this.buttonTable5.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable5.Name = "buttonTable5";
            this.buttonTable5.Size = new System.Drawing.Size(86, 62);
            this.buttonTable5.TabIndex = 34;
            this.buttonTable5.UseVisualStyleBackColor = false;
            // 
            // buttonTable6
            // 
            this.buttonTable6.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable6.FlatAppearance.BorderSize = 0;
            this.buttonTable6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable6.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable6.ForeColor = System.Drawing.Color.Black;
            this.buttonTable6.Location = new System.Drawing.Point(513, 61);
            this.buttonTable6.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable6.Name = "buttonTable6";
            this.buttonTable6.Size = new System.Drawing.Size(86, 62);
            this.buttonTable6.TabIndex = 33;
            this.buttonTable6.UseVisualStyleBackColor = false;
            // 
            // buttonTable10
            // 
            this.buttonTable10.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable10.FlatAppearance.BorderSize = 0;
            this.buttonTable10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable10.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable10.ForeColor = System.Drawing.Color.Black;
            this.buttonTable10.Location = new System.Drawing.Point(334, 127);
            this.buttonTable10.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable10.Name = "buttonTable10";
            this.buttonTable10.Size = new System.Drawing.Size(86, 62);
            this.buttonTable10.TabIndex = 32;
            this.buttonTable10.UseVisualStyleBackColor = false;
            // 
            // buttonTable11
            // 
            this.buttonTable11.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable11.FlatAppearance.BorderSize = 0;
            this.buttonTable11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable11.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable11.ForeColor = System.Drawing.Color.Black;
            this.buttonTable11.Location = new System.Drawing.Point(423, 127);
            this.buttonTable11.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable11.Name = "buttonTable11";
            this.buttonTable11.Size = new System.Drawing.Size(86, 62);
            this.buttonTable11.TabIndex = 31;
            this.buttonTable11.UseVisualStyleBackColor = false;
            // 
            // buttonTable12
            // 
            this.buttonTable12.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable12.FlatAppearance.BorderSize = 0;
            this.buttonTable12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable12.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable12.ForeColor = System.Drawing.Color.Black;
            this.buttonTable12.Location = new System.Drawing.Point(513, 127);
            this.buttonTable12.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable12.Name = "buttonTable12";
            this.buttonTable12.Size = new System.Drawing.Size(86, 62);
            this.buttonTable12.TabIndex = 30;
            this.buttonTable12.UseVisualStyleBackColor = false;
            // 
            // buttonTable16
            // 
            this.buttonTable16.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable16.FlatAppearance.BorderSize = 0;
            this.buttonTable16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable16.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable16.ForeColor = System.Drawing.Color.Black;
            this.buttonTable16.Location = new System.Drawing.Point(334, 194);
            this.buttonTable16.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable16.Name = "buttonTable16";
            this.buttonTable16.Size = new System.Drawing.Size(86, 62);
            this.buttonTable16.TabIndex = 29;
            this.buttonTable16.UseVisualStyleBackColor = false;
            // 
            // buttonTable17
            // 
            this.buttonTable17.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable17.FlatAppearance.BorderSize = 0;
            this.buttonTable17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable17.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable17.ForeColor = System.Drawing.Color.Black;
            this.buttonTable17.Location = new System.Drawing.Point(424, 194);
            this.buttonTable17.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable17.Name = "buttonTable17";
            this.buttonTable17.Size = new System.Drawing.Size(86, 62);
            this.buttonTable17.TabIndex = 28;
            this.buttonTable17.UseVisualStyleBackColor = false;
            // 
            // buttonTable18
            // 
            this.buttonTable18.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable18.FlatAppearance.BorderSize = 0;
            this.buttonTable18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable18.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable18.ForeColor = System.Drawing.Color.Black;
            this.buttonTable18.Location = new System.Drawing.Point(514, 194);
            this.buttonTable18.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable18.Name = "buttonTable18";
            this.buttonTable18.Size = new System.Drawing.Size(86, 62);
            this.buttonTable18.TabIndex = 27;
            this.buttonTable18.UseVisualStyleBackColor = false;
            // 
            // buttonTable22
            // 
            this.buttonTable22.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable22.FlatAppearance.BorderSize = 0;
            this.buttonTable22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable22.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable22.ForeColor = System.Drawing.Color.Black;
            this.buttonTable22.Location = new System.Drawing.Point(334, 260);
            this.buttonTable22.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable22.Name = "buttonTable22";
            this.buttonTable22.Size = new System.Drawing.Size(86, 62);
            this.buttonTable22.TabIndex = 26;
            this.buttonTable22.UseVisualStyleBackColor = false;
            // 
            // buttonTable23
            // 
            this.buttonTable23.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable23.FlatAppearance.BorderSize = 0;
            this.buttonTable23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable23.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable23.ForeColor = System.Drawing.Color.Black;
            this.buttonTable23.Location = new System.Drawing.Point(424, 260);
            this.buttonTable23.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable23.Name = "buttonTable23";
            this.buttonTable23.Size = new System.Drawing.Size(86, 62);
            this.buttonTable23.TabIndex = 25;
            this.buttonTable23.UseVisualStyleBackColor = false;
            // 
            // buttonTable24
            // 
            this.buttonTable24.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable24.FlatAppearance.BorderSize = 0;
            this.buttonTable24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable24.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable24.ForeColor = System.Drawing.Color.Black;
            this.buttonTable24.Location = new System.Drawing.Point(514, 260);
            this.buttonTable24.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable24.Name = "buttonTable24";
            this.buttonTable24.Size = new System.Drawing.Size(86, 62);
            this.buttonTable24.TabIndex = 24;
            this.buttonTable24.UseVisualStyleBackColor = false;
            // 
            // buttonTable1
            // 
            this.buttonTable1.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable1.FlatAppearance.BorderSize = 0;
            this.buttonTable1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable1.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable1.ForeColor = System.Drawing.Color.Black;
            this.buttonTable1.Location = new System.Drawing.Point(63, 61);
            this.buttonTable1.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable1.Name = "buttonTable1";
            this.buttonTable1.Size = new System.Drawing.Size(86, 62);
            this.buttonTable1.TabIndex = 23;
            this.buttonTable1.UseVisualStyleBackColor = false;
            // 
            // buttonTable2
            // 
            this.buttonTable2.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable2.FlatAppearance.BorderSize = 0;
            this.buttonTable2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable2.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable2.ForeColor = System.Drawing.Color.Black;
            this.buttonTable2.Location = new System.Drawing.Point(154, 61);
            this.buttonTable2.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable2.Name = "buttonTable2";
            this.buttonTable2.Size = new System.Drawing.Size(86, 62);
            this.buttonTable2.TabIndex = 22;
            this.buttonTable2.UseVisualStyleBackColor = false;
            // 
            // buttonTable3
            // 
            this.buttonTable3.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable3.FlatAppearance.BorderSize = 0;
            this.buttonTable3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable3.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable3.ForeColor = System.Drawing.Color.Black;
            this.buttonTable3.Location = new System.Drawing.Point(244, 61);
            this.buttonTable3.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable3.Name = "buttonTable3";
            this.buttonTable3.Size = new System.Drawing.Size(86, 62);
            this.buttonTable3.TabIndex = 21;
            this.buttonTable3.UseVisualStyleBackColor = false;
            // 
            // buttonTable7
            // 
            this.buttonTable7.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable7.FlatAppearance.BorderSize = 0;
            this.buttonTable7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable7.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable7.ForeColor = System.Drawing.Color.Black;
            this.buttonTable7.Location = new System.Drawing.Point(63, 127);
            this.buttonTable7.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable7.Name = "buttonTable7";
            this.buttonTable7.Size = new System.Drawing.Size(86, 62);
            this.buttonTable7.TabIndex = 20;
            this.buttonTable7.UseVisualStyleBackColor = false;
            // 
            // buttonTable8
            // 
            this.buttonTable8.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable8.FlatAppearance.BorderSize = 0;
            this.buttonTable8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable8.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable8.ForeColor = System.Drawing.Color.Black;
            this.buttonTable8.Location = new System.Drawing.Point(154, 127);
            this.buttonTable8.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable8.Name = "buttonTable8";
            this.buttonTable8.Size = new System.Drawing.Size(86, 62);
            this.buttonTable8.TabIndex = 19;
            this.buttonTable8.UseVisualStyleBackColor = false;
            // 
            // buttonTable9
            // 
            this.buttonTable9.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable9.FlatAppearance.BorderSize = 0;
            this.buttonTable9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable9.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable9.ForeColor = System.Drawing.Color.Black;
            this.buttonTable9.Location = new System.Drawing.Point(244, 127);
            this.buttonTable9.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable9.Name = "buttonTable9";
            this.buttonTable9.Size = new System.Drawing.Size(86, 62);
            this.buttonTable9.TabIndex = 18;
            this.buttonTable9.UseVisualStyleBackColor = false;
            // 
            // buttonTable13
            // 
            this.buttonTable13.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable13.FlatAppearance.BorderSize = 0;
            this.buttonTable13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable13.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable13.ForeColor = System.Drawing.Color.Black;
            this.buttonTable13.Location = new System.Drawing.Point(63, 194);
            this.buttonTable13.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable13.Name = "buttonTable13";
            this.buttonTable13.Size = new System.Drawing.Size(86, 62);
            this.buttonTable13.TabIndex = 17;
            this.buttonTable13.UseVisualStyleBackColor = false;
            // 
            // buttonTable14
            // 
            this.buttonTable14.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable14.FlatAppearance.BorderSize = 0;
            this.buttonTable14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable14.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable14.ForeColor = System.Drawing.Color.Black;
            this.buttonTable14.Location = new System.Drawing.Point(154, 194);
            this.buttonTable14.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable14.Name = "buttonTable14";
            this.buttonTable14.Size = new System.Drawing.Size(86, 62);
            this.buttonTable14.TabIndex = 16;
            this.buttonTable14.UseVisualStyleBackColor = false;
            // 
            // buttonTable15
            // 
            this.buttonTable15.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable15.FlatAppearance.BorderSize = 0;
            this.buttonTable15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable15.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable15.ForeColor = System.Drawing.Color.Black;
            this.buttonTable15.Location = new System.Drawing.Point(244, 194);
            this.buttonTable15.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable15.Name = "buttonTable15";
            this.buttonTable15.Size = new System.Drawing.Size(86, 62);
            this.buttonTable15.TabIndex = 15;
            this.buttonTable15.UseVisualStyleBackColor = false;
            // 
            // buttonTable19
            // 
            this.buttonTable19.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable19.FlatAppearance.BorderSize = 0;
            this.buttonTable19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable19.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable19.ForeColor = System.Drawing.Color.Black;
            this.buttonTable19.Location = new System.Drawing.Point(63, 260);
            this.buttonTable19.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable19.Name = "buttonTable19";
            this.buttonTable19.Size = new System.Drawing.Size(86, 62);
            this.buttonTable19.TabIndex = 14;
            this.buttonTable19.UseVisualStyleBackColor = false;
            // 
            // buttonTable20
            // 
            this.buttonTable20.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable20.FlatAppearance.BorderSize = 0;
            this.buttonTable20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable20.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable20.ForeColor = System.Drawing.Color.Black;
            this.buttonTable20.Location = new System.Drawing.Point(154, 260);
            this.buttonTable20.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable20.Name = "buttonTable20";
            this.buttonTable20.Size = new System.Drawing.Size(86, 62);
            this.buttonTable20.TabIndex = 13;
            this.buttonTable20.UseVisualStyleBackColor = false;
            // 
            // buttonTable21
            // 
            this.buttonTable21.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable21.FlatAppearance.BorderSize = 0;
            this.buttonTable21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable21.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable21.ForeColor = System.Drawing.Color.Black;
            this.buttonTable21.Location = new System.Drawing.Point(244, 260);
            this.buttonTable21.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable21.Name = "buttonTable21";
            this.buttonTable21.Size = new System.Drawing.Size(86, 62);
            this.buttonTable21.TabIndex = 12;
            this.buttonTable21.UseVisualStyleBackColor = false;
            // 
            // buttonTable28
            // 
            this.buttonTable28.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable28.FlatAppearance.BorderSize = 0;
            this.buttonTable28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable28.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable28.ForeColor = System.Drawing.Color.Black;
            this.buttonTable28.Location = new System.Drawing.Point(334, 326);
            this.buttonTable28.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable28.Name = "buttonTable28";
            this.buttonTable28.Size = new System.Drawing.Size(86, 62);
            this.buttonTable28.TabIndex = 11;
            this.buttonTable28.UseVisualStyleBackColor = false;
            // 
            // buttonTable29
            // 
            this.buttonTable29.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable29.FlatAppearance.BorderSize = 0;
            this.buttonTable29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable29.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable29.ForeColor = System.Drawing.Color.Black;
            this.buttonTable29.Location = new System.Drawing.Point(424, 326);
            this.buttonTable29.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable29.Name = "buttonTable29";
            this.buttonTable29.Size = new System.Drawing.Size(86, 62);
            this.buttonTable29.TabIndex = 10;
            this.buttonTable29.UseVisualStyleBackColor = false;
            // 
            // buttonTable30
            // 
            this.buttonTable30.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable30.FlatAppearance.BorderSize = 0;
            this.buttonTable30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable30.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable30.ForeColor = System.Drawing.Color.Black;
            this.buttonTable30.Location = new System.Drawing.Point(514, 326);
            this.buttonTable30.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable30.Name = "buttonTable30";
            this.buttonTable30.Size = new System.Drawing.Size(86, 62);
            this.buttonTable30.TabIndex = 9;
            this.buttonTable30.UseVisualStyleBackColor = false;
            // 
            // buttonTable25
            // 
            this.buttonTable25.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable25.FlatAppearance.BorderSize = 0;
            this.buttonTable25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable25.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable25.ForeColor = System.Drawing.Color.Black;
            this.buttonTable25.Location = new System.Drawing.Point(63, 326);
            this.buttonTable25.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable25.Name = "buttonTable25";
            this.buttonTable25.Size = new System.Drawing.Size(86, 62);
            this.buttonTable25.TabIndex = 8;
            this.buttonTable25.UseVisualStyleBackColor = false;
            // 
            // buttonTable26
            // 
            this.buttonTable26.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable26.FlatAppearance.BorderSize = 0;
            this.buttonTable26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable26.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable26.ForeColor = System.Drawing.Color.Black;
            this.buttonTable26.Location = new System.Drawing.Point(154, 326);
            this.buttonTable26.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable26.Name = "buttonTable26";
            this.buttonTable26.Size = new System.Drawing.Size(86, 62);
            this.buttonTable26.TabIndex = 7;
            this.buttonTable26.UseVisualStyleBackColor = false;
            // 
            // buttonTable27
            // 
            this.buttonTable27.BackColor = System.Drawing.SystemColors.Control;
            this.buttonTable27.FlatAppearance.BorderSize = 0;
            this.buttonTable27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTable27.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonTable27.ForeColor = System.Drawing.Color.Black;
            this.buttonTable27.Location = new System.Drawing.Point(244, 326);
            this.buttonTable27.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTable27.Name = "buttonTable27";
            this.buttonTable27.Size = new System.Drawing.Size(86, 62);
            this.buttonTable27.TabIndex = 6;
            this.buttonTable27.UseVisualStyleBackColor = false;
            // 
            // buttonTableNext
            // 
            this.buttonTableNext.BackColor = System.Drawing.SystemColors.ControlDark;
            this.buttonTableNext.FlatAppearance.BorderSize = 0;
            this.buttonTableNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTableNext.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTableNext.ForeColor = System.Drawing.Color.White;
            this.buttonTableNext.Location = new System.Drawing.Point(603, 61);
            this.buttonTableNext.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTableNext.Name = "buttonTableNext";
            this.buttonTableNext.Size = new System.Drawing.Size(52, 327);
            this.buttonTableNext.TabIndex = 5;
            this.buttonTableNext.Text = ">";
            this.buttonTableNext.UseVisualStyleBackColor = false;
            this.buttonTableNext.Click += new System.EventHandler(this.buttonTableNext_Click);
            // 
            // buttonTableGroupPageNext
            // 
            this.buttonTableGroupPageNext.BackColor = System.Drawing.Color.SteelBlue;
            this.buttonTableGroupPageNext.FlatAppearance.BorderSize = 0;
            this.buttonTableGroupPageNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTableGroupPageNext.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTableGroupPageNext.Location = new System.Drawing.Point(603, 6);
            this.buttonTableGroupPageNext.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTableGroupPageNext.Name = "buttonTableGroupPageNext";
            this.buttonTableGroupPageNext.Size = new System.Drawing.Size(52, 50);
            this.buttonTableGroupPageNext.TabIndex = 4;
            this.buttonTableGroupPageNext.Text = ">";
            this.buttonTableGroupPageNext.UseVisualStyleBackColor = false;
            this.buttonTableGroupPageNext.Click += new System.EventHandler(this.buttonTableGroupPageNext_Click);
            // 
            // buttonTablePrevious
            // 
            this.buttonTablePrevious.BackColor = System.Drawing.SystemColors.ControlDark;
            this.buttonTablePrevious.FlatAppearance.BorderSize = 0;
            this.buttonTablePrevious.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTablePrevious.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTablePrevious.ForeColor = System.Drawing.Color.White;
            this.buttonTablePrevious.Location = new System.Drawing.Point(6, 61);
            this.buttonTablePrevious.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTablePrevious.Name = "buttonTablePrevious";
            this.buttonTablePrevious.Size = new System.Drawing.Size(52, 327);
            this.buttonTablePrevious.TabIndex = 1;
            this.buttonTablePrevious.Text = "<";
            this.buttonTablePrevious.UseVisualStyleBackColor = false;
            this.buttonTablePrevious.Click += new System.EventHandler(this.buttonTablePrevious_Click);
            // 
            // buttonTableGroupPagePrevious
            // 
            this.buttonTableGroupPagePrevious.BackColor = System.Drawing.Color.SteelBlue;
            this.buttonTableGroupPagePrevious.FlatAppearance.BorderSize = 0;
            this.buttonTableGroupPagePrevious.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTableGroupPagePrevious.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTableGroupPagePrevious.Location = new System.Drawing.Point(6, 6);
            this.buttonTableGroupPagePrevious.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTableGroupPagePrevious.Name = "buttonTableGroupPagePrevious";
            this.buttonTableGroupPagePrevious.Size = new System.Drawing.Size(52, 50);
            this.buttonTableGroupPagePrevious.TabIndex = 0;
            this.buttonTableGroupPagePrevious.Text = "<";
            this.buttonTableGroupPagePrevious.UseVisualStyleBackColor = false;
            this.buttonTableGroupPagePrevious.Click += new System.EventHandler(this.buttonTableGroupPagePrevious_Click);
            // 
            // TrnPOSTouchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1096, 561);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "TrnPOSTouchForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TrnPOSTouchForm";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel3.ResumeLayout(false);
            this.tabControlSales.ResumeLayout(false);
            this.tabPageOpen.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOpenSalesList)).EndInit();
            this.tabPageBilledOut.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBilledOutSalesList)).EndInit();
            this.tabPageCollected.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCollectedSalesList)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panelWalkIn.ResumeLayout(false);
            this.panelWalkIn.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ImageList imageListPOSTouch;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TabControl tabControlSales;
        private System.Windows.Forms.TabPage tabPageOpen;
        private System.Windows.Forms.DataGridView dataGridViewOpenSalesList;
        private System.Windows.Forms.DataGridViewButtonColumn TabPageOpenColumnEdit;
        private System.Windows.Forms.DataGridViewButtonColumn TabPageOpenColumnDelete;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnId;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnTerminal;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnSalesDate;
        private System.Windows.Forms.DataGridViewLinkColumn TabPageOpenColumnSalesNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnManualSalesNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnRececiptInvoiceNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnCustomerCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnSalesAgent;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnTable;
        private System.Windows.Forms.DataGridViewCheckBoxColumn TabPageOpenColumnIsLocked;
        private System.Windows.Forms.DataGridViewCheckBoxColumn TabPageOpenColumnIsTendered;
        private System.Windows.Forms.DataGridViewCheckBoxColumn TabPageOpenColumnIsCancelled;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnDelivery;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn TabPageOpenColumnSpace;
        private System.Windows.Forms.TabPage tabPageBilledOut;
        private System.Windows.Forms.DataGridView dataGridViewBilledOutSalesList;
        private System.Windows.Forms.DataGridViewButtonColumn tabPageBilledOutColumnEdit;
        private System.Windows.Forms.DataGridViewButtonColumn tabPageBilledOutColumnDelete;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnId;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnTerminal;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnSalesDate;
        private System.Windows.Forms.DataGridViewLinkColumn tabPageBilledOutColumnSalesNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnManualSalesNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnInvoiceNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnCustomerCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnSalesAgent;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnTable;
        private System.Windows.Forms.DataGridViewCheckBoxColumn tabPageBilledOutColumnIsLocked;
        private System.Windows.Forms.DataGridViewCheckBoxColumn tabPageBilledOutColumnIsTendered;
        private System.Windows.Forms.DataGridViewCheckBoxColumn tabPageBilledOutColumnIsCancelled;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnDelivery;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageBilledOutColumnSpace;
        private System.Windows.Forms.TabPage tabPageCollected;
        private System.Windows.Forms.DataGridView dataGridViewCollectedSalesList;
        private System.Windows.Forms.DataGridViewButtonColumn tabPageCollectedColumnEdit;
        private System.Windows.Forms.DataGridViewButtonColumn tabPageCollectedColumnDelete;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnId;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnTerminal;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnSalesDate;
        private System.Windows.Forms.DataGridViewLinkColumn tabPageCollectedColumnSalesNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnManualSalesNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnCollectionNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnCustomerCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnCustomer;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnSalesAgent;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnTable;
        private System.Windows.Forms.DataGridViewCheckBoxColumn tabPageCollectedColumnIsLocked;
        private System.Windows.Forms.DataGridViewCheckBoxColumn tabPageCollectedColumnIsTendered;
        private System.Windows.Forms.DataGridViewCheckBoxColumn tabPageCollectedColumnIsCancelled;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnRemarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnDelivery;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn tabPageCollectedColumnSpace;
        private System.Windows.Forms.Panel panelWalkIn;
        private System.Windows.Forms.TextBox textBoxFilter;
        private System.Windows.Forms.ComboBox comboBoxTerminal;
        private System.Windows.Forms.DateTimePicker dateTimePickerSalesDate;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button buttonDelivery;
        private System.Windows.Forms.Button buttonWalkIn;
        private System.Windows.Forms.Button buttonTableGroup4;
        private System.Windows.Forms.Button buttonTableGroup5;
        private System.Windows.Forms.Button buttonTableGroup6;
        private System.Windows.Forms.Button buttonTableGroup1;
        private System.Windows.Forms.Button buttonTableGroup2;
        private System.Windows.Forms.Button buttonTableGroup3;
        private System.Windows.Forms.Button buttonTable4;
        private System.Windows.Forms.Button buttonTable5;
        private System.Windows.Forms.Button buttonTable6;
        private System.Windows.Forms.Button buttonTable10;
        private System.Windows.Forms.Button buttonTable11;
        private System.Windows.Forms.Button buttonTable12;
        private System.Windows.Forms.Button buttonTable16;
        private System.Windows.Forms.Button buttonTable17;
        private System.Windows.Forms.Button buttonTable18;
        private System.Windows.Forms.Button buttonTable22;
        private System.Windows.Forms.Button buttonTable23;
        private System.Windows.Forms.Button buttonTable24;
        private System.Windows.Forms.Button buttonTable1;
        private System.Windows.Forms.Button buttonTable2;
        private System.Windows.Forms.Button buttonTable3;
        private System.Windows.Forms.Button buttonTable7;
        private System.Windows.Forms.Button buttonTable8;
        private System.Windows.Forms.Button buttonTable9;
        private System.Windows.Forms.Button buttonTable13;
        private System.Windows.Forms.Button buttonTable14;
        private System.Windows.Forms.Button buttonTable15;
        private System.Windows.Forms.Button buttonTable19;
        private System.Windows.Forms.Button buttonTable20;
        private System.Windows.Forms.Button buttonTable21;
        private System.Windows.Forms.Button buttonTable28;
        private System.Windows.Forms.Button buttonTable29;
        private System.Windows.Forms.Button buttonTable30;
        private System.Windows.Forms.Button buttonTable25;
        private System.Windows.Forms.Button buttonTable26;
        private System.Windows.Forms.Button buttonTable27;
        private System.Windows.Forms.Button buttonTableNext;
        private System.Windows.Forms.Button buttonTableGroupPageNext;
        private System.Windows.Forms.Button buttonTablePrevious;
        private System.Windows.Forms.Button buttonTableGroupPagePrevious;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Button buttonHideItems;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox textBoxTotalAmount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button buttonTenderAll;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textBoxLastChange;
        private System.Windows.Forms.Label labelLastChange;
    }
}