﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyPOS.Entities
{
    public class SysFormEntity
    {
        public Int32 Id { get; set; }
        public String Form { get; set; }
        public String FormDescription { get; set; }
    }
}