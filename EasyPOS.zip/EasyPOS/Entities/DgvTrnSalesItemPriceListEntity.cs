﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyPOS.Entities
{
    public class DgvTrnSalesItemPriceListEntity
    {
        public String ColumnItemPriceListButtonPick { get; set; }
        public String ColumnItemPriceListPriceDescription { get; set; }
        public String ColumnItemPriceListPrice { get; set; }
    }
}