﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyPOS.Entities
{
    public class DgvMstSystemTablesUnitListEntity
    {
        public String ColumnUnitListButtonEdit { get; set; }
        public String ColumnUnitListButtonDelete { get; set; }
        public Int32 ColumnUnitListId { get; set; }
        public String ColumnUnitListUnit { get; set; }
    }
}
