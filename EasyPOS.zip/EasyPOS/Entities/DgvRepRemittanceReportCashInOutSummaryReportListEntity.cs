﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyPOS.Entities
{
    public class DgvRepRemittanceReportCashInOutSummaryReportListEntity
    {
        public String ColumnId { get; set; }
        public String ColumnDisbursementDate { get; set; }
        public String ColumnDisbursementNumber { get; set; }
        public String ColumnDisbursementType { get; set; }
        public String ColumnRemarks { get; set; }
        public String ColumnPayType { get; set; }
        public String ColumnUser { get; set; }
        public String ColumnAmount { get; set; }
    }
}
