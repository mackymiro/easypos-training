﻿namespace EasyPOS.Forms.Software.TrnPOS
{
    partial class TrnPOSTouchDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TrnPOSTouchDetailForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonOverRide = new System.Windows.Forms.Button();
            this.buttonPrint = new System.Windows.Forms.Button();
            this.buttonReturn = new System.Windows.Forms.Button();
            this.buttonDownload = new System.Windows.Forms.Button();
            this.buttonLock = new System.Windows.Forms.Button();
            this.buttonUnlock = new System.Windows.Forms.Button();
            this.buttonSearchItem = new System.Windows.Forms.Button();
            this.buttonDiscount = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonClose = new System.Windows.Forms.Button();
            this.buttonTender = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.textBoxTotalSalesAmount = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.labelCustomerCode = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelRemarks = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelCustomer = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.labelInvoiceDate = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelInvoiceNumber = new System.Windows.Forms.Label();
            this.buttonBarcode = new System.Windows.Forms.Button();
            this.textBoxBarcode = new System.Windows.Forms.TextBox();
            this.panelItems = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.imageListPOSTouchDetail = new System.Windows.Forms.ImageList(this.components);
            this.buttonWalkIn = new System.Windows.Forms.Button();
            this.buttonItemGroupItem28 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem29 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem30 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem25 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem26 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem27 = new System.Windows.Forms.Button();
            this.buttonItemGroup4 = new System.Windows.Forms.Button();
            this.buttonItemGroup5 = new System.Windows.Forms.Button();
            this.buttonItemGroup6 = new System.Windows.Forms.Button();
            this.buttonItemGroup1 = new System.Windows.Forms.Button();
            this.buttonItemGroup2 = new System.Windows.Forms.Button();
            this.buttonItemGroup3 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem4 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem5 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem6 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem10 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem11 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem12 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem16 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem17 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem18 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem1 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem2 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem3 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem7 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem8 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem9 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem13 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem14 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem15 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem22 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem23 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem24 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem19 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem20 = new System.Windows.Forms.Button();
            this.buttonItemGroupItem21 = new System.Windows.Forms.Button();
            this.buttonItemGroupItemNext = new System.Windows.Forms.Button();
            this.buttonItemGroupNext = new System.Windows.Forms.Button();
            this.buttonItemGroupItemPrevious = new System.Windows.Forms.Button();
            this.buttonItemGroupPrevious = new System.Windows.Forms.Button();
            this.dataGridViewSalesLineList = new System.Windows.Forms.DataGridView();
            this.ColumnSalesLineEdit = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ColumnSalesLineDelete = new System.Windows.Forms.DataGridViewButtonColumn();
            this.ColumnSalesLineId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineSalesId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineItemId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineItemDescription = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineQuantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineUnitId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineUnit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLinePrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineDiscountId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineDiscountRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineDiscountAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineNetPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineTaxId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineTax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineTaxRate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineTaxAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineSalesAccountId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineAssetAccountId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineCostAccountId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineTaxAccountId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineTimeStamp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLineUserId = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLinePreparation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLinePrice1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLinePrice2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLinePrice2LessTax = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSalesLinePriceSplitPercentage = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.textBoxLastChange = new System.Windows.Forms.TextBox();
            this.labelLastChange = new System.Windows.Forms.Label();
            this.buttonHideItems = new System.Windows.Forms.Button();
            this.printDialogSelectPrinter = new System.Windows.Forms.PrintDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panelItems.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSalesLineList)).BeginInit();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel8.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Controls.Add(this.buttonOverRide);
            this.panel1.Controls.Add(this.buttonPrint);
            this.panel1.Controls.Add(this.buttonReturn);
            this.panel1.Controls.Add(this.buttonDownload);
            this.panel1.Controls.Add(this.buttonLock);
            this.panel1.Controls.Add(this.buttonUnlock);
            this.panel1.Controls.Add(this.buttonSearchItem);
            this.panel1.Controls.Add(this.buttonDiscount);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.buttonClose);
            this.panel1.Controls.Add(this.buttonTender);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1096, 50);
            this.panel1.TabIndex = 4;
            // 
            // buttonOverRide
            // 
            this.buttonOverRide.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonOverRide.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonOverRide.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonOverRide.FlatAppearance.BorderSize = 0;
            this.buttonOverRide.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonOverRide.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonOverRide.ForeColor = System.Drawing.Color.White;
            this.buttonOverRide.Location = new System.Drawing.Point(897, 10);
            this.buttonOverRide.Margin = new System.Windows.Forms.Padding(2);
            this.buttonOverRide.Name = "buttonOverRide";
            this.buttonOverRide.Size = new System.Drawing.Size(115, 32);
            this.buttonOverRide.TabIndex = 27;
            this.buttonOverRide.TabStop = false;
            this.buttonOverRide.Text = "Override";
            this.buttonOverRide.UseVisualStyleBackColor = false;
            this.buttonOverRide.Click += new System.EventHandler(this.buttonOverRide_Click);
            // 
            // buttonPrint
            // 
            this.buttonPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonPrint.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonPrint.FlatAppearance.BorderSize = 0;
            this.buttonPrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonPrint.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonPrint.ForeColor = System.Drawing.Color.White;
            this.buttonPrint.Location = new System.Drawing.Point(439, 10);
            this.buttonPrint.Margin = new System.Windows.Forms.Padding(2);
            this.buttonPrint.Name = "buttonPrint";
            this.buttonPrint.Size = new System.Drawing.Size(70, 32);
            this.buttonPrint.TabIndex = 26;
            this.buttonPrint.TabStop = false;
            this.buttonPrint.Text = "Print";
            this.buttonPrint.UseVisualStyleBackColor = false;
            this.buttonPrint.Click += new System.EventHandler(this.buttonPrint_Click);
            // 
            // buttonReturn
            // 
            this.buttonReturn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonReturn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonReturn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonReturn.FlatAppearance.BorderSize = 0;
            this.buttonReturn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonReturn.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReturn.ForeColor = System.Drawing.Color.White;
            this.buttonReturn.Location = new System.Drawing.Point(661, 10);
            this.buttonReturn.Margin = new System.Windows.Forms.Padding(2);
            this.buttonReturn.Name = "buttonReturn";
            this.buttonReturn.Size = new System.Drawing.Size(77, 32);
            this.buttonReturn.TabIndex = 26;
            this.buttonReturn.TabStop = false;
            this.buttonReturn.Text = "Return";
            this.buttonReturn.UseVisualStyleBackColor = false;
            this.buttonReturn.Click += new System.EventHandler(this.buttonReturn_Click);
            // 
            // buttonDownload
            // 
            this.buttonDownload.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDownload.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.buttonDownload.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(34)))), ((int)(((byte)(116)))));
            this.buttonDownload.FlatAppearance.BorderSize = 0;
            this.buttonDownload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDownload.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.buttonDownload.ForeColor = System.Drawing.Color.White;
            this.buttonDownload.Location = new System.Drawing.Point(319, 10);
            this.buttonDownload.Margin = new System.Windows.Forms.Padding(2);
            this.buttonDownload.Name = "buttonDownload";
            this.buttonDownload.Size = new System.Drawing.Size(116, 32);
            this.buttonDownload.TabIndex = 25;
            this.buttonDownload.TabStop = false;
            this.buttonDownload.Text = "Download";
            this.buttonDownload.UseVisualStyleBackColor = false;
            this.buttonDownload.Click += new System.EventHandler(this.buttonDownload_Click);
            // 
            // buttonLock
            // 
            this.buttonLock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonLock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonLock.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonLock.FlatAppearance.BorderSize = 0;
            this.buttonLock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonLock.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonLock.ForeColor = System.Drawing.Color.White;
            this.buttonLock.Location = new System.Drawing.Point(513, 10);
            this.buttonLock.Margin = new System.Windows.Forms.Padding(2);
            this.buttonLock.Name = "buttonLock";
            this.buttonLock.Size = new System.Drawing.Size(70, 32);
            this.buttonLock.TabIndex = 6;
            this.buttonLock.TabStop = false;
            this.buttonLock.Text = "Lock";
            this.buttonLock.UseVisualStyleBackColor = false;
            this.buttonLock.Click += new System.EventHandler(this.buttonLock_Click);
            // 
            // buttonUnlock
            // 
            this.buttonUnlock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonUnlock.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonUnlock.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonUnlock.FlatAppearance.BorderSize = 0;
            this.buttonUnlock.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonUnlock.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonUnlock.ForeColor = System.Drawing.Color.White;
            this.buttonUnlock.Location = new System.Drawing.Point(587, 10);
            this.buttonUnlock.Margin = new System.Windows.Forms.Padding(2);
            this.buttonUnlock.Name = "buttonUnlock";
            this.buttonUnlock.Size = new System.Drawing.Size(70, 32);
            this.buttonUnlock.TabIndex = 5;
            this.buttonUnlock.TabStop = false;
            this.buttonUnlock.Text = "Unlock";
            this.buttonUnlock.UseVisualStyleBackColor = false;
            this.buttonUnlock.Click += new System.EventHandler(this.buttonUnlock_Click);
            // 
            // buttonSearchItem
            // 
            this.buttonSearchItem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSearchItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.buttonSearchItem.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(34)))), ((int)(((byte)(116)))));
            this.buttonSearchItem.FlatAppearance.BorderSize = 0;
            this.buttonSearchItem.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSearchItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.buttonSearchItem.ForeColor = System.Drawing.Color.White;
            this.buttonSearchItem.Location = new System.Drawing.Point(175, 10);
            this.buttonSearchItem.Margin = new System.Windows.Forms.Padding(2);
            this.buttonSearchItem.Name = "buttonSearchItem";
            this.buttonSearchItem.Size = new System.Drawing.Size(140, 32);
            this.buttonSearchItem.TabIndex = 8;
            this.buttonSearchItem.TabStop = false;
            this.buttonSearchItem.Text = "Search Item";
            this.buttonSearchItem.UseVisualStyleBackColor = false;
            this.buttonSearchItem.Click += new System.EventHandler(this.buttonSearchItem_Click);
            // 
            // buttonDiscount
            // 
            this.buttonDiscount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonDiscount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonDiscount.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonDiscount.FlatAppearance.BorderSize = 0;
            this.buttonDiscount.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonDiscount.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonDiscount.ForeColor = System.Drawing.Color.White;
            this.buttonDiscount.Location = new System.Drawing.Point(742, 10);
            this.buttonDiscount.Margin = new System.Windows.Forms.Padding(2);
            this.buttonDiscount.Name = "buttonDiscount";
            this.buttonDiscount.Size = new System.Drawing.Size(77, 32);
            this.buttonDiscount.TabIndex = 4;
            this.buttonDiscount.TabStop = false;
            this.buttonDiscount.Text = "Discount";
            this.buttonDiscount.UseVisualStyleBackColor = false;
            this.buttonDiscount.Click += new System.EventHandler(this.buttonDiscount_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::EasyPOS.Properties.Resources.POS_Touch;
            this.pictureBox1.Location = new System.Drawing.Point(10, 10);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(38, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(50, 14);
            this.label1.Margin = new System.Windows.Forms.Padding(0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 28);
            this.label1.TabIndex = 2;
            this.label1.Text = "Sales Detail";
            // 
            // buttonClose
            // 
            this.buttonClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(79)))), ((int)(((byte)(28)))));
            this.buttonClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(79)))), ((int)(((byte)(28)))));
            this.buttonClose.FlatAppearance.BorderSize = 0;
            this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClose.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonClose.ForeColor = System.Drawing.Color.White;
            this.buttonClose.Location = new System.Drawing.Point(1016, 10);
            this.buttonClose.Margin = new System.Windows.Forms.Padding(2);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(70, 32);
            this.buttonClose.TabIndex = 1;
            this.buttonClose.TabStop = false;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = false;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // buttonTender
            // 
            this.buttonTender.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonTender.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonTender.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonTender.FlatAppearance.BorderSize = 0;
            this.buttonTender.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonTender.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonTender.ForeColor = System.Drawing.Color.White;
            this.buttonTender.Location = new System.Drawing.Point(823, 10);
            this.buttonTender.Margin = new System.Windows.Forms.Padding(2);
            this.buttonTender.Name = "buttonTender";
            this.buttonTender.Size = new System.Drawing.Size(70, 32);
            this.buttonTender.TabIndex = 1;
            this.buttonTender.TabStop = false;
            this.buttonTender.Text = "Tender";
            this.buttonTender.UseVisualStyleBackColor = false;
            this.buttonTender.Click += new System.EventHandler(this.buttonTender_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.panel5);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.labelCustomerCode);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.labelRemarks);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.labelCustomer);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.labelInvoiceDate);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.labelInvoiceNumber);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 50);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1096, 58);
            this.panel2.TabIndex = 5;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.textBoxTotalSalesAmount);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(629, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(467, 58);
            this.panel5.TabIndex = 15;
            // 
            // textBoxTotalSalesAmount
            // 
            this.textBoxTotalSalesAmount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxTotalSalesAmount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBoxTotalSalesAmount.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxTotalSalesAmount.Font = new System.Drawing.Font("Segoe UI Semibold", 35F, System.Drawing.FontStyle.Bold);
            this.textBoxTotalSalesAmount.ForeColor = System.Drawing.Color.White;
            this.textBoxTotalSalesAmount.Location = new System.Drawing.Point(16, -5);
            this.textBoxTotalSalesAmount.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxTotalSalesAmount.Name = "textBoxTotalSalesAmount";
            this.textBoxTotalSalesAmount.ReadOnly = true;
            this.textBoxTotalSalesAmount.Size = new System.Drawing.Size(442, 63);
            this.textBoxTotalSalesAmount.TabIndex = 1;
            this.textBoxTotalSalesAmount.TabStop = false;
            this.textBoxTotalSalesAmount.Text = "0.00";
            this.textBoxTotalSalesAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label7.Location = new System.Drawing.Point(171, 6);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 15);
            this.label7.TabIndex = 13;
            this.label7.Text = "Code:";
            // 
            // labelCustomerCode
            // 
            this.labelCustomerCode.AutoSize = true;
            this.labelCustomerCode.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.labelCustomerCode.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelCustomerCode.Location = new System.Drawing.Point(236, 6);
            this.labelCustomerCode.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelCustomerCode.Name = "labelCustomerCode";
            this.labelCustomerCode.Size = new System.Drawing.Size(70, 15);
            this.labelCustomerCode.TabIndex = 14;
            this.labelCustomerCode.Text = "000000000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label2.Location = new System.Drawing.Point(11, 36);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 15);
            this.label2.TabIndex = 11;
            this.label2.Text = "Remarks:";
            // 
            // labelRemarks
            // 
            this.labelRemarks.AutoEllipsis = true;
            this.labelRemarks.AutoSize = true;
            this.labelRemarks.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.labelRemarks.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelRemarks.Location = new System.Drawing.Point(83, 36);
            this.labelRemarks.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelRemarks.Name = "labelRemarks";
            this.labelRemarks.Size = new System.Drawing.Size(56, 15);
            this.labelRemarks.TabIndex = 12;
            this.labelRemarks.Text = "Remarks";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label6.Location = new System.Drawing.Point(171, 21);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 15);
            this.label6.TabIndex = 9;
            this.label6.Text = "Customer:";
            // 
            // labelCustomer
            // 
            this.labelCustomer.AutoSize = true;
            this.labelCustomer.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.labelCustomer.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelCustomer.Location = new System.Drawing.Point(236, 21);
            this.labelCustomer.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelCustomer.Name = "labelCustomer";
            this.labelCustomer.Size = new System.Drawing.Size(97, 15);
            this.labelCustomer.TabIndex = 10;
            this.labelCustomer.Text = "Customer Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label4.Location = new System.Drawing.Point(11, 21);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "Order Date:";
            // 
            // labelInvoiceDate
            // 
            this.labelInvoiceDate.AutoSize = true;
            this.labelInvoiceDate.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.labelInvoiceDate.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelInvoiceDate.Location = new System.Drawing.Point(83, 21);
            this.labelInvoiceDate.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelInvoiceDate.Name = "labelInvoiceDate";
            this.labelInvoiceDate.Size = new System.Drawing.Size(77, 15);
            this.labelInvoiceDate.TabIndex = 8;
            this.labelInvoiceDate.Text = "MM/dd/yyyy";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label3.Location = new System.Drawing.Point(11, 6);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 15);
            this.label3.TabIndex = 5;
            this.label3.Text = "Order No.:";
            // 
            // labelInvoiceNumber
            // 
            this.labelInvoiceNumber.AutoSize = true;
            this.labelInvoiceNumber.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.labelInvoiceNumber.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.labelInvoiceNumber.Location = new System.Drawing.Point(83, 6);
            this.labelInvoiceNumber.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelInvoiceNumber.Name = "labelInvoiceNumber";
            this.labelInvoiceNumber.Size = new System.Drawing.Size(77, 15);
            this.labelInvoiceNumber.TabIndex = 6;
            this.labelInvoiceNumber.Text = "0000000000";
            // 
            // buttonBarcode
            // 
            this.buttonBarcode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.buttonBarcode.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(34)))), ((int)(((byte)(116)))));
            this.buttonBarcode.FlatAppearance.BorderSize = 0;
            this.buttonBarcode.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonBarcode.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.buttonBarcode.ForeColor = System.Drawing.Color.White;
            this.buttonBarcode.Location = new System.Drawing.Point(45, 6);
            this.buttonBarcode.Margin = new System.Windows.Forms.Padding(2);
            this.buttonBarcode.Name = "buttonBarcode";
            this.buttonBarcode.Size = new System.Drawing.Size(97, 32);
            this.buttonBarcode.TabIndex = 9;
            this.buttonBarcode.TabStop = false;
            this.buttonBarcode.Text = "Barcode";
            this.buttonBarcode.UseVisualStyleBackColor = false;
            this.buttonBarcode.Click += new System.EventHandler(this.buttonBarcode_Click);
            // 
            // textBoxBarcode
            // 
            this.textBoxBarcode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxBarcode.Font = new System.Drawing.Font("Segoe UI Semibold", 13.3F, System.Drawing.FontStyle.Bold);
            this.textBoxBarcode.Location = new System.Drawing.Point(146, 6);
            this.textBoxBarcode.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxBarcode.Name = "textBoxBarcode";
            this.textBoxBarcode.Size = new System.Drawing.Size(284, 31);
            this.textBoxBarcode.TabIndex = 7;
            this.textBoxBarcode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBoxBarcode_KeyDown);
            // 
            // panelItems
            // 
            this.panelItems.BackColor = System.Drawing.Color.White;
            this.panelItems.Controls.Add(this.button4);
            this.panelItems.Controls.Add(this.buttonWalkIn);
            this.panelItems.Controls.Add(this.buttonItemGroupItem28);
            this.panelItems.Controls.Add(this.buttonItemGroupItem29);
            this.panelItems.Controls.Add(this.buttonItemGroupItem30);
            this.panelItems.Controls.Add(this.buttonItemGroupItem25);
            this.panelItems.Controls.Add(this.buttonItemGroupItem26);
            this.panelItems.Controls.Add(this.buttonItemGroupItem27);
            this.panelItems.Controls.Add(this.buttonItemGroup4);
            this.panelItems.Controls.Add(this.buttonItemGroup5);
            this.panelItems.Controls.Add(this.buttonItemGroup6);
            this.panelItems.Controls.Add(this.buttonItemGroup1);
            this.panelItems.Controls.Add(this.buttonItemGroup2);
            this.panelItems.Controls.Add(this.buttonItemGroup3);
            this.panelItems.Controls.Add(this.buttonItemGroupItem4);
            this.panelItems.Controls.Add(this.buttonItemGroupItem5);
            this.panelItems.Controls.Add(this.buttonItemGroupItem6);
            this.panelItems.Controls.Add(this.buttonItemGroupItem10);
            this.panelItems.Controls.Add(this.buttonItemGroupItem11);
            this.panelItems.Controls.Add(this.buttonItemGroupItem12);
            this.panelItems.Controls.Add(this.buttonItemGroupItem16);
            this.panelItems.Controls.Add(this.buttonItemGroupItem17);
            this.panelItems.Controls.Add(this.buttonItemGroupItem18);
            this.panelItems.Controls.Add(this.buttonItemGroupItem1);
            this.panelItems.Controls.Add(this.buttonItemGroupItem2);
            this.panelItems.Controls.Add(this.buttonItemGroupItem3);
            this.panelItems.Controls.Add(this.buttonItemGroupItem7);
            this.panelItems.Controls.Add(this.buttonItemGroupItem8);
            this.panelItems.Controls.Add(this.buttonItemGroupItem9);
            this.panelItems.Controls.Add(this.buttonItemGroupItem13);
            this.panelItems.Controls.Add(this.buttonItemGroupItem14);
            this.panelItems.Controls.Add(this.buttonItemGroupItem15);
            this.panelItems.Controls.Add(this.buttonItemGroupItem22);
            this.panelItems.Controls.Add(this.buttonItemGroupItem23);
            this.panelItems.Controls.Add(this.buttonItemGroupItem24);
            this.panelItems.Controls.Add(this.buttonItemGroupItem19);
            this.panelItems.Controls.Add(this.buttonItemGroupItem20);
            this.panelItems.Controls.Add(this.buttonItemGroupItem21);
            this.panelItems.Controls.Add(this.buttonItemGroupItemNext);
            this.panelItems.Controls.Add(this.buttonItemGroupNext);
            this.panelItems.Controls.Add(this.buttonItemGroupItemPrevious);
            this.panelItems.Controls.Add(this.buttonItemGroupPrevious);
            this.panelItems.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelItems.Location = new System.Drawing.Point(0, 0);
            this.panelItems.Margin = new System.Windows.Forms.Padding(2);
            this.panelItems.Name = "panelItems";
            this.panelItems.Padding = new System.Windows.Forms.Padding(4);
            this.panelItems.Size = new System.Drawing.Size(662, 453);
            this.panelItems.TabIndex = 23;
            // 
            // button4
            // 
            this.button4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.button4.FlatAppearance.BorderSize = 0;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.button4.ForeColor = System.Drawing.Color.White;
            this.button4.ImageKey = "scanQRCode.png";
            this.button4.ImageList = this.imageListPOSTouchDetail;
            this.button4.Location = new System.Drawing.Point(334, 393);
            this.button4.Margin = new System.Windows.Forms.Padding(2);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(322, 54);
            this.button4.TabIndex = 51;
            this.button4.Text = "\r\nScan QR Code";
            this.button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button4.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // imageListPOSTouchDetail
            // 
            this.imageListPOSTouchDetail.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListPOSTouchDetail.ImageStream")));
            this.imageListPOSTouchDetail.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListPOSTouchDetail.Images.SetKeyName(0, "changeTable.png");
            this.imageListPOSTouchDetail.Images.SetKeyName(1, "scanQRCode.png");
            // 
            // buttonWalkIn
            // 
            this.buttonWalkIn.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.buttonWalkIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.buttonWalkIn.FlatAppearance.BorderSize = 0;
            this.buttonWalkIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonWalkIn.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.buttonWalkIn.ForeColor = System.Drawing.Color.White;
            this.buttonWalkIn.ImageKey = "changeTable.png";
            this.buttonWalkIn.ImageList = this.imageListPOSTouchDetail;
            this.buttonWalkIn.Location = new System.Drawing.Point(6, 393);
            this.buttonWalkIn.Margin = new System.Windows.Forms.Padding(2);
            this.buttonWalkIn.Name = "buttonWalkIn";
            this.buttonWalkIn.Size = new System.Drawing.Size(323, 54);
            this.buttonWalkIn.TabIndex = 50;
            this.buttonWalkIn.Text = "\r\nChange Table";
            this.buttonWalkIn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.buttonWalkIn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageAboveText;
            this.buttonWalkIn.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem28
            // 
            this.buttonItemGroupItem28.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem28.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem28.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem28.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem28.Location = new System.Drawing.Point(334, 326);
            this.buttonItemGroupItem28.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem28.Name = "buttonItemGroupItem28";
            this.buttonItemGroupItem28.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem28.TabIndex = 49;
            this.buttonItemGroupItem28.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem29
            // 
            this.buttonItemGroupItem29.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem29.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem29.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem29.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem29.Location = new System.Drawing.Point(424, 326);
            this.buttonItemGroupItem29.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem29.Name = "buttonItemGroupItem29";
            this.buttonItemGroupItem29.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem29.TabIndex = 48;
            this.buttonItemGroupItem29.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem30
            // 
            this.buttonItemGroupItem30.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem30.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem30.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem30.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem30.Location = new System.Drawing.Point(514, 326);
            this.buttonItemGroupItem30.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem30.Name = "buttonItemGroupItem30";
            this.buttonItemGroupItem30.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem30.TabIndex = 47;
            this.buttonItemGroupItem30.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem25
            // 
            this.buttonItemGroupItem25.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem25.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem25.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem25.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem25.Location = new System.Drawing.Point(63, 326);
            this.buttonItemGroupItem25.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem25.Name = "buttonItemGroupItem25";
            this.buttonItemGroupItem25.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem25.TabIndex = 46;
            this.buttonItemGroupItem25.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem26
            // 
            this.buttonItemGroupItem26.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem26.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem26.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem26.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem26.Location = new System.Drawing.Point(154, 326);
            this.buttonItemGroupItem26.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem26.Name = "buttonItemGroupItem26";
            this.buttonItemGroupItem26.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem26.TabIndex = 45;
            this.buttonItemGroupItem26.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem27
            // 
            this.buttonItemGroupItem27.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem27.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem27.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem27.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem27.Location = new System.Drawing.Point(244, 326);
            this.buttonItemGroupItem27.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem27.Name = "buttonItemGroupItem27";
            this.buttonItemGroupItem27.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem27.TabIndex = 44;
            this.buttonItemGroupItem27.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroup4
            // 
            this.buttonItemGroup4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonItemGroup4.FlatAppearance.BorderSize = 0;
            this.buttonItemGroup4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroup4.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonItemGroup4.ForeColor = System.Drawing.Color.White;
            this.buttonItemGroup4.Location = new System.Drawing.Point(334, 6);
            this.buttonItemGroup4.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroup4.Name = "buttonItemGroup4";
            this.buttonItemGroup4.Size = new System.Drawing.Size(85, 50);
            this.buttonItemGroup4.TabIndex = 41;
            this.buttonItemGroup4.UseVisualStyleBackColor = false;
            this.buttonItemGroup4.Click += new System.EventHandler(this.buttonItemGroup4_Click);
            // 
            // buttonItemGroup5
            // 
            this.buttonItemGroup5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonItemGroup5.FlatAppearance.BorderSize = 0;
            this.buttonItemGroup5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroup5.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonItemGroup5.ForeColor = System.Drawing.Color.White;
            this.buttonItemGroup5.Location = new System.Drawing.Point(424, 6);
            this.buttonItemGroup5.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroup5.Name = "buttonItemGroup5";
            this.buttonItemGroup5.Size = new System.Drawing.Size(85, 50);
            this.buttonItemGroup5.TabIndex = 40;
            this.buttonItemGroup5.UseVisualStyleBackColor = false;
            this.buttonItemGroup5.Click += new System.EventHandler(this.buttonItemGroup5_Click);
            // 
            // buttonItemGroup6
            // 
            this.buttonItemGroup6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonItemGroup6.FlatAppearance.BorderSize = 0;
            this.buttonItemGroup6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroup6.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonItemGroup6.ForeColor = System.Drawing.Color.White;
            this.buttonItemGroup6.Location = new System.Drawing.Point(514, 6);
            this.buttonItemGroup6.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroup6.Name = "buttonItemGroup6";
            this.buttonItemGroup6.Size = new System.Drawing.Size(86, 50);
            this.buttonItemGroup6.TabIndex = 39;
            this.buttonItemGroup6.UseVisualStyleBackColor = false;
            this.buttonItemGroup6.Click += new System.EventHandler(this.buttonItemGroup6_Click);
            // 
            // buttonItemGroup1
            // 
            this.buttonItemGroup1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonItemGroup1.FlatAppearance.BorderSize = 0;
            this.buttonItemGroup1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroup1.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonItemGroup1.ForeColor = System.Drawing.Color.White;
            this.buttonItemGroup1.Location = new System.Drawing.Point(63, 6);
            this.buttonItemGroup1.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroup1.Name = "buttonItemGroup1";
            this.buttonItemGroup1.Size = new System.Drawing.Size(86, 50);
            this.buttonItemGroup1.TabIndex = 38;
            this.buttonItemGroup1.UseVisualStyleBackColor = false;
            this.buttonItemGroup1.Click += new System.EventHandler(this.buttonItemGroup1_Click);
            // 
            // buttonItemGroup2
            // 
            this.buttonItemGroup2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonItemGroup2.FlatAppearance.BorderSize = 0;
            this.buttonItemGroup2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroup2.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonItemGroup2.ForeColor = System.Drawing.Color.White;
            this.buttonItemGroup2.Location = new System.Drawing.Point(154, 6);
            this.buttonItemGroup2.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroup2.Name = "buttonItemGroup2";
            this.buttonItemGroup2.Size = new System.Drawing.Size(86, 50);
            this.buttonItemGroup2.TabIndex = 37;
            this.buttonItemGroup2.UseVisualStyleBackColor = false;
            this.buttonItemGroup2.Click += new System.EventHandler(this.buttonItemGroup2_Click);
            // 
            // buttonItemGroup3
            // 
            this.buttonItemGroup3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(1)))), ((int)(((byte)(166)))), ((int)(((byte)(240)))));
            this.buttonItemGroup3.FlatAppearance.BorderSize = 0;
            this.buttonItemGroup3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroup3.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonItemGroup3.ForeColor = System.Drawing.Color.White;
            this.buttonItemGroup3.Location = new System.Drawing.Point(244, 6);
            this.buttonItemGroup3.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroup3.Name = "buttonItemGroup3";
            this.buttonItemGroup3.Size = new System.Drawing.Size(85, 50);
            this.buttonItemGroup3.TabIndex = 36;
            this.buttonItemGroup3.UseVisualStyleBackColor = false;
            this.buttonItemGroup3.Click += new System.EventHandler(this.buttonItemGroup3_Click);
            // 
            // buttonItemGroupItem4
            // 
            this.buttonItemGroupItem4.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem4.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem4.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem4.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem4.Location = new System.Drawing.Point(334, 61);
            this.buttonItemGroupItem4.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem4.Name = "buttonItemGroupItem4";
            this.buttonItemGroupItem4.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem4.TabIndex = 32;
            this.buttonItemGroupItem4.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem5
            // 
            this.buttonItemGroupItem5.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem5.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem5.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem5.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem5.Location = new System.Drawing.Point(424, 61);
            this.buttonItemGroupItem5.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem5.Name = "buttonItemGroupItem5";
            this.buttonItemGroupItem5.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem5.TabIndex = 31;
            this.buttonItemGroupItem5.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem6
            // 
            this.buttonItemGroupItem6.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem6.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem6.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem6.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem6.Location = new System.Drawing.Point(514, 61);
            this.buttonItemGroupItem6.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem6.Name = "buttonItemGroupItem6";
            this.buttonItemGroupItem6.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem6.TabIndex = 30;
            this.buttonItemGroupItem6.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem10
            // 
            this.buttonItemGroupItem10.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem10.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem10.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem10.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem10.Location = new System.Drawing.Point(334, 127);
            this.buttonItemGroupItem10.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem10.Name = "buttonItemGroupItem10";
            this.buttonItemGroupItem10.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem10.TabIndex = 29;
            this.buttonItemGroupItem10.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem11
            // 
            this.buttonItemGroupItem11.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem11.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem11.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem11.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem11.Location = new System.Drawing.Point(424, 127);
            this.buttonItemGroupItem11.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem11.Name = "buttonItemGroupItem11";
            this.buttonItemGroupItem11.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem11.TabIndex = 28;
            this.buttonItemGroupItem11.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem12
            // 
            this.buttonItemGroupItem12.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem12.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem12.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem12.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem12.Location = new System.Drawing.Point(514, 127);
            this.buttonItemGroupItem12.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem12.Name = "buttonItemGroupItem12";
            this.buttonItemGroupItem12.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem12.TabIndex = 27;
            this.buttonItemGroupItem12.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem16
            // 
            this.buttonItemGroupItem16.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem16.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem16.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem16.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem16.Location = new System.Drawing.Point(334, 194);
            this.buttonItemGroupItem16.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem16.Name = "buttonItemGroupItem16";
            this.buttonItemGroupItem16.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem16.TabIndex = 26;
            this.buttonItemGroupItem16.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem17
            // 
            this.buttonItemGroupItem17.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem17.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem17.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem17.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem17.Location = new System.Drawing.Point(424, 194);
            this.buttonItemGroupItem17.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem17.Name = "buttonItemGroupItem17";
            this.buttonItemGroupItem17.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem17.TabIndex = 25;
            this.buttonItemGroupItem17.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem18
            // 
            this.buttonItemGroupItem18.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem18.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem18.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem18.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem18.Location = new System.Drawing.Point(514, 194);
            this.buttonItemGroupItem18.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem18.Name = "buttonItemGroupItem18";
            this.buttonItemGroupItem18.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem18.TabIndex = 24;
            this.buttonItemGroupItem18.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem1
            // 
            this.buttonItemGroupItem1.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem1.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem1.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem1.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem1.Location = new System.Drawing.Point(63, 61);
            this.buttonItemGroupItem1.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem1.Name = "buttonItemGroupItem1";
            this.buttonItemGroupItem1.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem1.TabIndex = 20;
            this.buttonItemGroupItem1.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem2
            // 
            this.buttonItemGroupItem2.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem2.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem2.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem2.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem2.Location = new System.Drawing.Point(154, 61);
            this.buttonItemGroupItem2.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem2.Name = "buttonItemGroupItem2";
            this.buttonItemGroupItem2.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem2.TabIndex = 19;
            this.buttonItemGroupItem2.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem3
            // 
            this.buttonItemGroupItem3.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem3.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem3.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem3.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem3.Location = new System.Drawing.Point(244, 61);
            this.buttonItemGroupItem3.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem3.Name = "buttonItemGroupItem3";
            this.buttonItemGroupItem3.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem3.TabIndex = 18;
            this.buttonItemGroupItem3.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem7
            // 
            this.buttonItemGroupItem7.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem7.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem7.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem7.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem7.Location = new System.Drawing.Point(63, 127);
            this.buttonItemGroupItem7.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem7.Name = "buttonItemGroupItem7";
            this.buttonItemGroupItem7.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem7.TabIndex = 17;
            this.buttonItemGroupItem7.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem8
            // 
            this.buttonItemGroupItem8.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem8.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem8.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem8.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem8.Location = new System.Drawing.Point(154, 127);
            this.buttonItemGroupItem8.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem8.Name = "buttonItemGroupItem8";
            this.buttonItemGroupItem8.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem8.TabIndex = 16;
            this.buttonItemGroupItem8.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem9
            // 
            this.buttonItemGroupItem9.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem9.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem9.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem9.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem9.Location = new System.Drawing.Point(244, 127);
            this.buttonItemGroupItem9.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem9.Name = "buttonItemGroupItem9";
            this.buttonItemGroupItem9.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem9.TabIndex = 15;
            this.buttonItemGroupItem9.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem13
            // 
            this.buttonItemGroupItem13.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem13.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem13.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem13.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem13.Location = new System.Drawing.Point(63, 194);
            this.buttonItemGroupItem13.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem13.Name = "buttonItemGroupItem13";
            this.buttonItemGroupItem13.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem13.TabIndex = 14;
            this.buttonItemGroupItem13.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem14
            // 
            this.buttonItemGroupItem14.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem14.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem14.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem14.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem14.Location = new System.Drawing.Point(154, 194);
            this.buttonItemGroupItem14.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem14.Name = "buttonItemGroupItem14";
            this.buttonItemGroupItem14.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem14.TabIndex = 13;
            this.buttonItemGroupItem14.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem15
            // 
            this.buttonItemGroupItem15.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem15.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem15.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem15.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem15.Location = new System.Drawing.Point(244, 194);
            this.buttonItemGroupItem15.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem15.Name = "buttonItemGroupItem15";
            this.buttonItemGroupItem15.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem15.TabIndex = 12;
            this.buttonItemGroupItem15.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem22
            // 
            this.buttonItemGroupItem22.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem22.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem22.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem22.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem22.Location = new System.Drawing.Point(334, 260);
            this.buttonItemGroupItem22.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem22.Name = "buttonItemGroupItem22";
            this.buttonItemGroupItem22.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem22.TabIndex = 11;
            this.buttonItemGroupItem22.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem23
            // 
            this.buttonItemGroupItem23.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem23.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem23.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem23.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem23.Location = new System.Drawing.Point(424, 260);
            this.buttonItemGroupItem23.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem23.Name = "buttonItemGroupItem23";
            this.buttonItemGroupItem23.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem23.TabIndex = 10;
            this.buttonItemGroupItem23.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem24
            // 
            this.buttonItemGroupItem24.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem24.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem24.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem24.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem24.Location = new System.Drawing.Point(514, 260);
            this.buttonItemGroupItem24.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem24.Name = "buttonItemGroupItem24";
            this.buttonItemGroupItem24.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem24.TabIndex = 9;
            this.buttonItemGroupItem24.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem19
            // 
            this.buttonItemGroupItem19.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem19.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem19.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem19.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem19.Location = new System.Drawing.Point(63, 260);
            this.buttonItemGroupItem19.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem19.Name = "buttonItemGroupItem19";
            this.buttonItemGroupItem19.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem19.TabIndex = 8;
            this.buttonItemGroupItem19.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem20
            // 
            this.buttonItemGroupItem20.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem20.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem20.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem20.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem20.Location = new System.Drawing.Point(154, 260);
            this.buttonItemGroupItem20.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem20.Name = "buttonItemGroupItem20";
            this.buttonItemGroupItem20.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem20.TabIndex = 7;
            this.buttonItemGroupItem20.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItem21
            // 
            this.buttonItemGroupItem21.BackColor = System.Drawing.SystemColors.Control;
            this.buttonItemGroupItem21.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItem21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItem21.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.buttonItemGroupItem21.ForeColor = System.Drawing.Color.Black;
            this.buttonItemGroupItem21.Location = new System.Drawing.Point(244, 260);
            this.buttonItemGroupItem21.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItem21.Name = "buttonItemGroupItem21";
            this.buttonItemGroupItem21.Size = new System.Drawing.Size(86, 62);
            this.buttonItemGroupItem21.TabIndex = 6;
            this.buttonItemGroupItem21.UseVisualStyleBackColor = false;
            // 
            // buttonItemGroupItemNext
            // 
            this.buttonItemGroupItemNext.BackColor = System.Drawing.SystemColors.ControlDark;
            this.buttonItemGroupItemNext.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItemNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItemNext.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonItemGroupItemNext.ForeColor = System.Drawing.Color.White;
            this.buttonItemGroupItemNext.Location = new System.Drawing.Point(604, 61);
            this.buttonItemGroupItemNext.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItemNext.Name = "buttonItemGroupItemNext";
            this.buttonItemGroupItemNext.Size = new System.Drawing.Size(52, 327);
            this.buttonItemGroupItemNext.TabIndex = 5;
            this.buttonItemGroupItemNext.Text = ">";
            this.buttonItemGroupItemNext.UseVisualStyleBackColor = false;
            this.buttonItemGroupItemNext.Click += new System.EventHandler(this.buttonItemGroupItemNext_Click);
            // 
            // buttonItemGroupNext
            // 
            this.buttonItemGroupNext.BackColor = System.Drawing.Color.SteelBlue;
            this.buttonItemGroupNext.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupNext.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupNext.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonItemGroupNext.ForeColor = System.Drawing.Color.White;
            this.buttonItemGroupNext.Location = new System.Drawing.Point(604, 6);
            this.buttonItemGroupNext.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupNext.Name = "buttonItemGroupNext";
            this.buttonItemGroupNext.Size = new System.Drawing.Size(52, 50);
            this.buttonItemGroupNext.TabIndex = 4;
            this.buttonItemGroupNext.Text = ">";
            this.buttonItemGroupNext.UseVisualStyleBackColor = false;
            this.buttonItemGroupNext.Click += new System.EventHandler(this.buttonItemGroupNext_Click);
            // 
            // buttonItemGroupItemPrevious
            // 
            this.buttonItemGroupItemPrevious.BackColor = System.Drawing.SystemColors.ControlDark;
            this.buttonItemGroupItemPrevious.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupItemPrevious.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupItemPrevious.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonItemGroupItemPrevious.ForeColor = System.Drawing.Color.White;
            this.buttonItemGroupItemPrevious.Location = new System.Drawing.Point(6, 61);
            this.buttonItemGroupItemPrevious.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupItemPrevious.Name = "buttonItemGroupItemPrevious";
            this.buttonItemGroupItemPrevious.Size = new System.Drawing.Size(52, 327);
            this.buttonItemGroupItemPrevious.TabIndex = 1;
            this.buttonItemGroupItemPrevious.Text = "<";
            this.buttonItemGroupItemPrevious.UseVisualStyleBackColor = false;
            this.buttonItemGroupItemPrevious.Click += new System.EventHandler(this.buttonItemGroupItemPrevious_Click);
            // 
            // buttonItemGroupPrevious
            // 
            this.buttonItemGroupPrevious.BackColor = System.Drawing.Color.SteelBlue;
            this.buttonItemGroupPrevious.FlatAppearance.BorderSize = 0;
            this.buttonItemGroupPrevious.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonItemGroupPrevious.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonItemGroupPrevious.ForeColor = System.Drawing.Color.White;
            this.buttonItemGroupPrevious.Location = new System.Drawing.Point(6, 6);
            this.buttonItemGroupPrevious.Margin = new System.Windows.Forms.Padding(2);
            this.buttonItemGroupPrevious.Name = "buttonItemGroupPrevious";
            this.buttonItemGroupPrevious.Size = new System.Drawing.Size(52, 50);
            this.buttonItemGroupPrevious.TabIndex = 0;
            this.buttonItemGroupPrevious.Text = "<";
            this.buttonItemGroupPrevious.UseVisualStyleBackColor = false;
            this.buttonItemGroupPrevious.Click += new System.EventHandler(this.buttonItemGroupPrevious_Click);
            // 
            // dataGridViewSalesLineList
            // 
            this.dataGridViewSalesLineList.AllowUserToAddRows = false;
            this.dataGridViewSalesLineList.AllowUserToDeleteRows = false;
            this.dataGridViewSalesLineList.AllowUserToResizeRows = false;
            this.dataGridViewSalesLineList.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewSalesLineList.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewSalesLineList.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewSalesLineList.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSalesLineList.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnSalesLineEdit,
            this.ColumnSalesLineDelete,
            this.ColumnSalesLineId,
            this.ColumnSalesLineSalesId,
            this.ColumnSalesLineItemId,
            this.ColumnSalesLineItemDescription,
            this.ColumnSalesLineQuantity,
            this.ColumnSalesLineUnitId,
            this.ColumnSalesLineUnit,
            this.ColumnSalesLinePrice,
            this.ColumnSalesLineDiscountId,
            this.ColumnSalesLineDiscount,
            this.ColumnSalesLineDiscountRate,
            this.ColumnSalesLineDiscountAmount,
            this.ColumnSalesLineNetPrice,
            this.ColumnSalesLineAmount,
            this.ColumnSalesLineTaxId,
            this.ColumnSalesLineTax,
            this.ColumnSalesLineTaxRate,
            this.ColumnSalesLineTaxAmount,
            this.ColumnSalesLineSalesAccountId,
            this.ColumnSalesLineAssetAccountId,
            this.ColumnSalesLineCostAccountId,
            this.ColumnSalesLineTaxAccountId,
            this.ColumnSalesLineTimeStamp,
            this.ColumnSalesLineUserId,
            this.ColumnSalesLinePreparation,
            this.ColumnSalesLinePrice1,
            this.ColumnSalesLinePrice2,
            this.ColumnSalesLinePrice2LessTax,
            this.ColumnSalesLinePriceSplitPercentage});
            this.dataGridViewSalesLineList.Location = new System.Drawing.Point(4, 42);
            this.dataGridViewSalesLineList.Margin = new System.Windows.Forms.Padding(2);
            this.dataGridViewSalesLineList.MultiSelect = false;
            this.dataGridViewSalesLineList.Name = "dataGridViewSalesLineList";
            this.dataGridViewSalesLineList.ReadOnly = true;
            this.dataGridViewSalesLineList.RowHeadersVisible = false;
            this.dataGridViewSalesLineList.RowTemplate.Height = 24;
            this.dataGridViewSalesLineList.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewSalesLineList.Size = new System.Drawing.Size(426, 354);
            this.dataGridViewSalesLineList.TabIndex = 24;
            this.dataGridViewSalesLineList.TabStop = false;
            this.dataGridViewSalesLineList.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewSalesLineList_CellClick);
            // 
            // ColumnSalesLineEdit
            // 
            this.ColumnSalesLineEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ColumnSalesLineEdit.Frozen = true;
            this.ColumnSalesLineEdit.HeaderText = "";
            this.ColumnSalesLineEdit.Name = "ColumnSalesLineEdit";
            this.ColumnSalesLineEdit.ReadOnly = true;
            this.ColumnSalesLineEdit.Width = 70;
            // 
            // ColumnSalesLineDelete
            // 
            this.ColumnSalesLineDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ColumnSalesLineDelete.Frozen = true;
            this.ColumnSalesLineDelete.HeaderText = "";
            this.ColumnSalesLineDelete.Name = "ColumnSalesLineDelete";
            this.ColumnSalesLineDelete.ReadOnly = true;
            this.ColumnSalesLineDelete.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ColumnSalesLineDelete.Width = 70;
            // 
            // ColumnSalesLineId
            // 
            this.ColumnSalesLineId.HeaderText = "Id";
            this.ColumnSalesLineId.Name = "ColumnSalesLineId";
            this.ColumnSalesLineId.ReadOnly = true;
            this.ColumnSalesLineId.Visible = false;
            // 
            // ColumnSalesLineSalesId
            // 
            this.ColumnSalesLineSalesId.HeaderText = "SalesId";
            this.ColumnSalesLineSalesId.Name = "ColumnSalesLineSalesId";
            this.ColumnSalesLineSalesId.ReadOnly = true;
            this.ColumnSalesLineSalesId.Visible = false;
            // 
            // ColumnSalesLineItemId
            // 
            this.ColumnSalesLineItemId.HeaderText = "ItemId";
            this.ColumnSalesLineItemId.Name = "ColumnSalesLineItemId";
            this.ColumnSalesLineItemId.ReadOnly = true;
            this.ColumnSalesLineItemId.Visible = false;
            // 
            // ColumnSalesLineItemDescription
            // 
            this.ColumnSalesLineItemDescription.HeaderText = "Item Description";
            this.ColumnSalesLineItemDescription.Name = "ColumnSalesLineItemDescription";
            this.ColumnSalesLineItemDescription.ReadOnly = true;
            this.ColumnSalesLineItemDescription.Width = 200;
            // 
            // ColumnSalesLineQuantity
            // 
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnSalesLineQuantity.DefaultCellStyle = dataGridViewCellStyle2;
            this.ColumnSalesLineQuantity.HeaderText = "Quantity";
            this.ColumnSalesLineQuantity.Name = "ColumnSalesLineQuantity";
            this.ColumnSalesLineQuantity.ReadOnly = true;
            // 
            // ColumnSalesLineUnitId
            // 
            this.ColumnSalesLineUnitId.HeaderText = "UnitId";
            this.ColumnSalesLineUnitId.Name = "ColumnSalesLineUnitId";
            this.ColumnSalesLineUnitId.ReadOnly = true;
            this.ColumnSalesLineUnitId.Visible = false;
            // 
            // ColumnSalesLineUnit
            // 
            this.ColumnSalesLineUnit.HeaderText = "Unit";
            this.ColumnSalesLineUnit.Name = "ColumnSalesLineUnit";
            this.ColumnSalesLineUnit.ReadOnly = true;
            // 
            // ColumnSalesLinePrice
            // 
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnSalesLinePrice.DefaultCellStyle = dataGridViewCellStyle3;
            this.ColumnSalesLinePrice.HeaderText = "Price";
            this.ColumnSalesLinePrice.Name = "ColumnSalesLinePrice";
            this.ColumnSalesLinePrice.ReadOnly = true;
            // 
            // ColumnSalesLineDiscountId
            // 
            this.ColumnSalesLineDiscountId.HeaderText = "DiscountId";
            this.ColumnSalesLineDiscountId.Name = "ColumnSalesLineDiscountId";
            this.ColumnSalesLineDiscountId.ReadOnly = true;
            this.ColumnSalesLineDiscountId.Visible = false;
            // 
            // ColumnSalesLineDiscount
            // 
            this.ColumnSalesLineDiscount.HeaderText = "Discount";
            this.ColumnSalesLineDiscount.Name = "ColumnSalesLineDiscount";
            this.ColumnSalesLineDiscount.ReadOnly = true;
            this.ColumnSalesLineDiscount.Visible = false;
            // 
            // ColumnSalesLineDiscountRate
            // 
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnSalesLineDiscountRate.DefaultCellStyle = dataGridViewCellStyle4;
            this.ColumnSalesLineDiscountRate.HeaderText = "Discount %";
            this.ColumnSalesLineDiscountRate.Name = "ColumnSalesLineDiscountRate";
            this.ColumnSalesLineDiscountRate.ReadOnly = true;
            this.ColumnSalesLineDiscountRate.Width = 110;
            // 
            // ColumnSalesLineDiscountAmount
            // 
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnSalesLineDiscountAmount.DefaultCellStyle = dataGridViewCellStyle5;
            this.ColumnSalesLineDiscountAmount.HeaderText = "Discount";
            this.ColumnSalesLineDiscountAmount.Name = "ColumnSalesLineDiscountAmount";
            this.ColumnSalesLineDiscountAmount.ReadOnly = true;
            // 
            // ColumnSalesLineNetPrice
            // 
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnSalesLineNetPrice.DefaultCellStyle = dataGridViewCellStyle6;
            this.ColumnSalesLineNetPrice.HeaderText = "Net Price";
            this.ColumnSalesLineNetPrice.Name = "ColumnSalesLineNetPrice";
            this.ColumnSalesLineNetPrice.ReadOnly = true;
            // 
            // ColumnSalesLineAmount
            // 
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnSalesLineAmount.DefaultCellStyle = dataGridViewCellStyle7;
            this.ColumnSalesLineAmount.HeaderText = "Amount";
            this.ColumnSalesLineAmount.Name = "ColumnSalesLineAmount";
            this.ColumnSalesLineAmount.ReadOnly = true;
            // 
            // ColumnSalesLineTaxId
            // 
            this.ColumnSalesLineTaxId.HeaderText = "TaxId";
            this.ColumnSalesLineTaxId.Name = "ColumnSalesLineTaxId";
            this.ColumnSalesLineTaxId.ReadOnly = true;
            this.ColumnSalesLineTaxId.Visible = false;
            // 
            // ColumnSalesLineTax
            // 
            this.ColumnSalesLineTax.HeaderText = "Tax";
            this.ColumnSalesLineTax.Name = "ColumnSalesLineTax";
            this.ColumnSalesLineTax.ReadOnly = true;
            this.ColumnSalesLineTax.Visible = false;
            // 
            // ColumnSalesLineTaxRate
            // 
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnSalesLineTaxRate.DefaultCellStyle = dataGridViewCellStyle8;
            this.ColumnSalesLineTaxRate.HeaderText = "Tax %";
            this.ColumnSalesLineTaxRate.Name = "ColumnSalesLineTaxRate";
            this.ColumnSalesLineTaxRate.ReadOnly = true;
            // 
            // ColumnSalesLineTaxAmount
            // 
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.ColumnSalesLineTaxAmount.DefaultCellStyle = dataGridViewCellStyle9;
            this.ColumnSalesLineTaxAmount.HeaderText = "Tax";
            this.ColumnSalesLineTaxAmount.Name = "ColumnSalesLineTaxAmount";
            this.ColumnSalesLineTaxAmount.ReadOnly = true;
            // 
            // ColumnSalesLineSalesAccountId
            // 
            this.ColumnSalesLineSalesAccountId.HeaderText = "SalesAccountId";
            this.ColumnSalesLineSalesAccountId.Name = "ColumnSalesLineSalesAccountId";
            this.ColumnSalesLineSalesAccountId.ReadOnly = true;
            this.ColumnSalesLineSalesAccountId.Visible = false;
            // 
            // ColumnSalesLineAssetAccountId
            // 
            this.ColumnSalesLineAssetAccountId.HeaderText = "AssetAccountId";
            this.ColumnSalesLineAssetAccountId.Name = "ColumnSalesLineAssetAccountId";
            this.ColumnSalesLineAssetAccountId.ReadOnly = true;
            this.ColumnSalesLineAssetAccountId.Visible = false;
            // 
            // ColumnSalesLineCostAccountId
            // 
            this.ColumnSalesLineCostAccountId.HeaderText = "CostAccountId";
            this.ColumnSalesLineCostAccountId.Name = "ColumnSalesLineCostAccountId";
            this.ColumnSalesLineCostAccountId.ReadOnly = true;
            this.ColumnSalesLineCostAccountId.Visible = false;
            // 
            // ColumnSalesLineTaxAccountId
            // 
            this.ColumnSalesLineTaxAccountId.HeaderText = "TaxAccountId";
            this.ColumnSalesLineTaxAccountId.Name = "ColumnSalesLineTaxAccountId";
            this.ColumnSalesLineTaxAccountId.ReadOnly = true;
            this.ColumnSalesLineTaxAccountId.Visible = false;
            // 
            // ColumnSalesLineTimeStamp
            // 
            this.ColumnSalesLineTimeStamp.HeaderText = "SalesLineTimeStamp";
            this.ColumnSalesLineTimeStamp.Name = "ColumnSalesLineTimeStamp";
            this.ColumnSalesLineTimeStamp.ReadOnly = true;
            this.ColumnSalesLineTimeStamp.Visible = false;
            // 
            // ColumnSalesLineUserId
            // 
            this.ColumnSalesLineUserId.HeaderText = "UserId";
            this.ColumnSalesLineUserId.Name = "ColumnSalesLineUserId";
            this.ColumnSalesLineUserId.ReadOnly = true;
            this.ColumnSalesLineUserId.Visible = false;
            // 
            // ColumnSalesLinePreparation
            // 
            this.ColumnSalesLinePreparation.HeaderText = "Preparation";
            this.ColumnSalesLinePreparation.Name = "ColumnSalesLinePreparation";
            this.ColumnSalesLinePreparation.ReadOnly = true;
            this.ColumnSalesLinePreparation.Visible = false;
            // 
            // ColumnSalesLinePrice1
            // 
            this.ColumnSalesLinePrice1.HeaderText = "Price1";
            this.ColumnSalesLinePrice1.Name = "ColumnSalesLinePrice1";
            this.ColumnSalesLinePrice1.ReadOnly = true;
            this.ColumnSalesLinePrice1.Visible = false;
            // 
            // ColumnSalesLinePrice2
            // 
            this.ColumnSalesLinePrice2.HeaderText = "Price2";
            this.ColumnSalesLinePrice2.Name = "ColumnSalesLinePrice2";
            this.ColumnSalesLinePrice2.ReadOnly = true;
            this.ColumnSalesLinePrice2.Visible = false;
            // 
            // ColumnSalesLinePrice2LessTax
            // 
            this.ColumnSalesLinePrice2LessTax.HeaderText = "Price2LessTax";
            this.ColumnSalesLinePrice2LessTax.Name = "ColumnSalesLinePrice2LessTax";
            this.ColumnSalesLinePrice2LessTax.ReadOnly = true;
            this.ColumnSalesLinePrice2LessTax.Visible = false;
            // 
            // ColumnSalesLinePriceSplitPercentage
            // 
            this.ColumnSalesLinePriceSplitPercentage.HeaderText = "PriceSplitPercentage";
            this.ColumnSalesLinePriceSplitPercentage.Name = "ColumnSalesLinePriceSplitPercentage";
            this.ColumnSalesLinePriceSplitPercentage.ReadOnly = true;
            this.ColumnSalesLinePriceSplitPercentage.Visible = false;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel3);
            this.panel4.Controls.Add(this.panelItems);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 108);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1096, 453);
            this.panel4.TabIndex = 25;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Controls.Add(this.textBoxBarcode);
            this.panel3.Controls.Add(this.buttonHideItems);
            this.panel3.Controls.Add(this.dataGridViewSalesLineList);
            this.panel3.Controls.Add(this.buttonBarcode);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(662, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(434, 453);
            this.panel3.TabIndex = 26;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.panel8);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel6.Location = new System.Drawing.Point(0, 401);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(434, 52);
            this.panel6.TabIndex = 26;
            // 
            // panel8
            // 
            this.panel8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel8.BackColor = System.Drawing.Color.White;
            this.panel8.Controls.Add(this.textBoxLastChange);
            this.panel8.Controls.Add(this.labelLastChange);
            this.panel8.Location = new System.Drawing.Point(4, 5);
            this.panel8.Margin = new System.Windows.Forms.Padding(2);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(426, 42);
            this.panel8.TabIndex = 58;
            // 
            // textBoxLastChange
            // 
            this.textBoxLastChange.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxLastChange.BackColor = System.Drawing.Color.White;
            this.textBoxLastChange.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxLastChange.Font = new System.Drawing.Font("Segoe UI", 15F);
            this.textBoxLastChange.ForeColor = System.Drawing.Color.Black;
            this.textBoxLastChange.Location = new System.Drawing.Point(124, 6);
            this.textBoxLastChange.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxLastChange.Name = "textBoxLastChange";
            this.textBoxLastChange.ReadOnly = true;
            this.textBoxLastChange.Size = new System.Drawing.Size(292, 27);
            this.textBoxLastChange.TabIndex = 17;
            this.textBoxLastChange.Text = "0.00";
            this.textBoxLastChange.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // labelLastChange
            // 
            this.labelLastChange.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.labelLastChange.AutoSize = true;
            this.labelLastChange.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.labelLastChange.ForeColor = System.Drawing.Color.Black;
            this.labelLastChange.Location = new System.Drawing.Point(10, 11);
            this.labelLastChange.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.labelLastChange.Name = "labelLastChange";
            this.labelLastChange.Size = new System.Drawing.Size(98, 20);
            this.labelLastChange.TabIndex = 16;
            this.labelLastChange.Text = "Last Change:";
            // 
            // buttonHideItems
            // 
            this.buttonHideItems.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(188)))), ((int)(((byte)(0)))));
            this.buttonHideItems.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(34)))), ((int)(((byte)(116)))));
            this.buttonHideItems.FlatAppearance.BorderSize = 0;
            this.buttonHideItems.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonHideItems.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Bold);
            this.buttonHideItems.ForeColor = System.Drawing.Color.White;
            this.buttonHideItems.Location = new System.Drawing.Point(4, 6);
            this.buttonHideItems.Margin = new System.Windows.Forms.Padding(2);
            this.buttonHideItems.Name = "buttonHideItems";
            this.buttonHideItems.Size = new System.Drawing.Size(37, 32);
            this.buttonHideItems.TabIndex = 25;
            this.buttonHideItems.TabStop = false;
            this.buttonHideItems.Text = "=";
            this.buttonHideItems.UseVisualStyleBackColor = false;
            this.buttonHideItems.Click += new System.EventHandler(this.buttonHideItems_Click);
            // 
            // printDialogSelectPrinter
            // 
            this.printDialogSelectPrinter.UseEXDialog = true;
            // 
            // TrnPOSTouchDetailForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(1096, 561);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "TrnPOSTouchDetailForm";
            this.Text = "TrnPOSTouchDetail";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panelItems.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSalesLineList)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Button buttonTender;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelCustomer;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelInvoiceDate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelInvoiceNumber;
        private System.Windows.Forms.TextBox textBoxTotalSalesAmount;
        private System.Windows.Forms.Button buttonBarcode;
        private System.Windows.Forms.Button buttonSearchItem;
        private System.Windows.Forms.TextBox textBoxBarcode;
        private System.Windows.Forms.Panel panelItems;
        private System.Windows.Forms.Button buttonItemGroup4;
        private System.Windows.Forms.Button buttonItemGroup5;
        private System.Windows.Forms.Button buttonItemGroup6;
        private System.Windows.Forms.Button buttonItemGroup1;
        private System.Windows.Forms.Button buttonItemGroup2;
        private System.Windows.Forms.Button buttonItemGroup3;
        private System.Windows.Forms.Button buttonItemGroupItem4;
        private System.Windows.Forms.Button buttonItemGroupItem5;
        private System.Windows.Forms.Button buttonItemGroupItem6;
        private System.Windows.Forms.Button buttonItemGroupItem10;
        private System.Windows.Forms.Button buttonItemGroupItem11;
        private System.Windows.Forms.Button buttonItemGroupItem12;
        private System.Windows.Forms.Button buttonItemGroupItem16;
        private System.Windows.Forms.Button buttonItemGroupItem17;
        private System.Windows.Forms.Button buttonItemGroupItem18;
        private System.Windows.Forms.Button buttonItemGroupItem1;
        private System.Windows.Forms.Button buttonItemGroupItem2;
        private System.Windows.Forms.Button buttonItemGroupItem3;
        private System.Windows.Forms.Button buttonItemGroupItem7;
        private System.Windows.Forms.Button buttonItemGroupItem8;
        private System.Windows.Forms.Button buttonItemGroupItem9;
        private System.Windows.Forms.Button buttonItemGroupItem13;
        private System.Windows.Forms.Button buttonItemGroupItem14;
        private System.Windows.Forms.Button buttonItemGroupItem15;
        private System.Windows.Forms.Button buttonItemGroupItem22;
        private System.Windows.Forms.Button buttonItemGroupItem23;
        private System.Windows.Forms.Button buttonItemGroupItem24;
        private System.Windows.Forms.Button buttonItemGroupItem19;
        private System.Windows.Forms.Button buttonItemGroupItem20;
        private System.Windows.Forms.Button buttonItemGroupItem21;
        private System.Windows.Forms.Button buttonItemGroupItemNext;
        private System.Windows.Forms.Button buttonItemGroupNext;
        private System.Windows.Forms.Button buttonItemGroupItemPrevious;
        private System.Windows.Forms.Button buttonItemGroupPrevious;
        private System.Windows.Forms.Button buttonDiscount;
        private System.Windows.Forms.DataGridView dataGridViewSalesLineList;
        private System.Windows.Forms.Button buttonLock;
        private System.Windows.Forms.Button buttonUnlock;
        private System.Windows.Forms.Button buttonItemGroupItem28;
        private System.Windows.Forms.Button buttonItemGroupItem29;
        private System.Windows.Forms.Button buttonItemGroupItem30;
        private System.Windows.Forms.Button buttonItemGroupItem25;
        private System.Windows.Forms.Button buttonItemGroupItem26;
        private System.Windows.Forms.Button buttonItemGroupItem27;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ImageList imageListPOSTouchDetail;
        private System.Windows.Forms.Button buttonWalkIn;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button buttonDownload;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label labelCustomerCode;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelRemarks;
        private System.Windows.Forms.Button buttonReturn;
        private System.Windows.Forms.Button buttonPrint;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button buttonOverRide;
        private System.Windows.Forms.Button buttonHideItems;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PrintDialog printDialogSelectPrinter;
        private System.Windows.Forms.DataGridViewButtonColumn ColumnSalesLineEdit;
        private System.Windows.Forms.DataGridViewButtonColumn ColumnSalesLineDelete;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineSalesId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineItemId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineItemDescription;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineQuantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineUnitId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineUnit;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLinePrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineDiscountId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineDiscountRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineDiscountAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineNetPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineTaxId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineTax;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineTaxRate;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineTaxAmount;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineSalesAccountId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineAssetAccountId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineCostAccountId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineTaxAccountId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineTimeStamp;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLineUserId;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLinePreparation;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLinePrice1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLinePrice2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLinePrice2LessTax;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSalesLinePriceSplitPercentage;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox textBoxLastChange;
        private System.Windows.Forms.Label labelLastChange;
    }
}