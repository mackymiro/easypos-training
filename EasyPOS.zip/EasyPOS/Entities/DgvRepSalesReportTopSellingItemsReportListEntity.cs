﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EasyPOS.Entities
{
    public class DgvRepSalesReportTopSellingItemsReportListEntity
    {
        public String ColumnNumber { get; set; }
        public String ColumnItemCode { get; set; }
        public String ColumnItemDescription { get; set; }
        public String ColumnItemCategory { get; set; }
        public String ColumnQuantity { get; set; }
        public String ColumnUnit { get; set; }
        public String ColumnPrice { get; set; }
        public String ColumnAmount { get; set; }
    }
}
